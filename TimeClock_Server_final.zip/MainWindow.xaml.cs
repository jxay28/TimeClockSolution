using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using Microsoft.VisualBasic; // per InputBox festività
using TimeClock.Core.Models;
using TimeClock.Core.Services;
using System.Text.Json;
using System.Windows.Controls;


namespace TimeClock.Server
{
    public partial class MainWindow : Window
    {
        // percorso della cartella condivisa con i CSV
        private string _csvFolder;

        // elenco utenti caricati
        private List<UserProfile> _users = new List<UserProfile>();

        // elenco festività caricate
        private List<Holiday> _holidays = new List<Holiday>();

        // Parametri globali: unica fonte di verità è parametri_straordinari.json (App.ParametriGlobali)
        // Non usiamo più parametri_straordinari.csv per la logica.

        // Evita loop quando lo slider viene “snappato” ai valori ammessi.
        private bool _isSnappingOvertimeSlider;

        public MainWindow()
        {
            InitializeComponent();

            // Aggancio eventi per parametri straordinari (senza cambiare il design)
            if (FindName("SaturdayCheck") is System.Windows.Controls.CheckBox sat)
            {
                sat.Checked += WeekendCheck_Changed;
                sat.Unchecked += WeekendCheck_Changed;
            }
            if (FindName("SundayCheck") is System.Windows.Controls.CheckBox sun)
            {
                sun.Checked += WeekendCheck_Changed;
                sun.Unchecked += WeekendCheck_Changed;
            }

            // Legge l'ultima cartella salvata nelle impostazioni
            _csvFolder = Properties.Settings.Default.CsvFolderPath;

            if (!string.IsNullOrWhiteSpace(_csvFolder) && Directory.Exists(_csvFolder))
            {
                CsvPathBox.Text = _csvFolder;

                // Carica subito i dati
                LoadUsers();
                LoadHolidays();
                LoadSettings();
            }
            else
            {
                CsvPathBox.Text = "Nessuna cartella selezionata";
                _csvFolder = string.Empty;
            }
        }

        /// <summary>
        /// Carica l'elenco degli utenti dal file utenti.csv e aggiorna griglia e combo.
        /// CSV: Id,SequenceNumber,Nome,Cognome,Ruolo,DataAssunzione,Ore,Base,Extra
        /// </summary>
        /// <summary>
        /// Carica l'elenco degli utenti dal file utenti.json (master).
        /// Se utenti.json non esiste, prova a migrare da utenti.csv.
        /// Aggiorna griglia e combo.
        /// </summary>
        private void LoadUsers()
        {
            _users = new List<UserProfile>();

            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            string jsonPath = Path.Combine(_csvFolder, "utenti.json");
            string csvPath = Path.Combine(_csvFolder, "utenti.csv");

            // 1) JSON master
            if (File.Exists(jsonPath))
            {
                try
                {
                    string json = File.ReadAllText(jsonPath);

                    // Nuovo formato (utenti.json master) con campi extra
                    var persisted = JsonSerializer.Deserialize<List<UserProfileExtras.Persisted>>(json);
                    if (persisted != null)
                    {
                        foreach (var p in persisted)
                        {
                            var user = new UserProfile
                            {
                                Id = p.Id,
                                SequenceNumber = p.SequenceNumber,
                                Nome = p.Nome,
                                Cognome = p.Cognome,
                                Ruolo = p.Ruolo,
                                DataAssunzione = p.DataAssunzione,
                                OreContrattoSettimanali = p.OreContrattoSettimanali,
                                CompensoOrarioBase = p.CompensoOrarioBase,
                                CompensoOrarioExtra = p.CompensoOrarioExtra,
                                OrarioIngresso1 = p.OrarioIngresso1,
                                OrarioUscita1 = p.OrarioUscita1,
                                OrarioIngresso2 = p.OrarioIngresso2,
                                OrarioUscita2 = p.OrarioUscita2
                            };

                            // Collega i campi extra (non presenti nel Core)
                            user.SetOreGiornalierePreviste(p.OreGiornalierePreviste);
                            user.SetGiorniLavorativiSettimana(p.GiorniLavorativiSettimana);

                            // Normalizza le ore settimanali: se ho ore giorno + giorni, le ricalcolo
                            if (p.OreGiornalierePreviste > 0 && p.GiorniLavorativiSettimana > 0)
                                user.OreContrattoSettimanali = p.OreGiornalierePreviste * p.GiorniLavorativiSettimana;

                            _users.Add(user);
                        }
                    }
                    else
                    {
                        // Compatibilità: vecchio formato (solo UserProfile)
                        var list = JsonSerializer.Deserialize<List<UserProfile>>(json);
                        if (list != null)
                            _users = list;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Errore durante il caricamento di utenti.json: {ex.Message}");
                }
            }
            // 2) Prima esecuzione: migra da CSV se presente
            else if (File.Exists(csvPath))
            {
                try
                {
                    var repo = new CsvRepository();

                    foreach (var fields in repo.Load(csvPath))
                    {
                        try
                        {
                            var user = new UserProfile
                            {
                                Id = fields.ElementAtOrDefault(0) ?? string.Empty,
                                SequenceNumber = int.TryParse(fields.ElementAtOrDefault(1), out var seq) ? seq : 0,
                                Nome = fields.ElementAtOrDefault(2) ?? string.Empty,
                                Cognome = fields.ElementAtOrDefault(3) ?? string.Empty,
                                Ruolo = fields.ElementAtOrDefault(4) ?? string.Empty,
                                DataAssunzione = DateTime.TryParse(fields.ElementAtOrDefault(5), out var d) ? d : DateTime.MinValue,
                                OreContrattoSettimanali = double.TryParse(fields.ElementAtOrDefault(6),
                                    System.Globalization.NumberStyles.Any,
                                    System.Globalization.CultureInfo.InvariantCulture,
                                    out var ore)
                                    ? ore
                                    : 0,
                                CompensoOrarioBase = decimal.TryParse(fields.ElementAtOrDefault(7),
                                    System.Globalization.NumberStyles.Any,
                                    System.Globalization.CultureInfo.InvariantCulture,
                                    out var cb)
                                    ? cb
                                    : 0,
                                CompensoOrarioExtra = decimal.TryParse(fields.ElementAtOrDefault(8),
                                    System.Globalization.NumberStyles.Any,
                                    System.Globalization.CultureInfo.InvariantCulture,
                                    out var ce)
                                    ? ce
                                    : 0,
                                // Campi extra orari (se non ci sono nel CSV restano vuoti)
                                OrarioIngresso1 = fields.ElementAtOrDefault(9),
                                OrarioUscita1 = fields.ElementAtOrDefault(10),
                                OrarioIngresso2 = fields.ElementAtOrDefault(11),
                                OrarioUscita2 = fields.ElementAtOrDefault(12)
                            };

                            _users.Add(user);
                        }
                        catch
                        {
                            // ignora la riga malformata
                        }
                    }

                    // una volta caricati dal CSV, salviamo subito in JSON+CSV pulito
                    SaveUsers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Errore durante il caricamento di utenti.csv: {ex.Message}");
                }
            }

            // aggiorna la griglia degli utenti
            var grid = this.FindName("UsersGrid") as DataGrid;
            if (grid != null)
            {
                grid.ItemsSource = null;
                grid.ItemsSource = _users;
            }

            // aggiorna la combo per il report
            var combo = this.FindName("UserSelectorReport") as ComboBox;
            if (combo != null)
            {
                combo.ItemsSource = null;
                combo.ItemsSource = _users;
            }
        }
        /// <summary>
        /// Salva gli utenti su utenti.json (master) e genera anche utenti.csv per compatibilità.
        /// </summary>
        private void SaveUsers()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            string jsonPath = Path.Combine(_csvFolder, "utenti.json");
            string csvPath = Path.Combine(_csvFolder, "utenti.csv");

            // Salvataggio JSON
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };

                // Salviamo in un DTO persistente che include anche i campi extra
                var persisted = _users.Select(u =>
                {
                    var fallbackGiorni = 5;
                    var oreGiornoFallback = (u.OreContrattoSettimanali > 0) ? (u.OreContrattoSettimanali / fallbackGiorni) : 0;
                    var oreGiorno = u.GetOreGiornalierePreviste(oreGiornoFallback);
                    var giorni = u.GetGiorniLavorativiSettimana(fallbackGiorni);
                    var oreSett = (oreGiorno > 0 && giorni > 0) ? oreGiorno * giorni : u.OreContrattoSettimanali;
                    u.OreContrattoSettimanali = oreSett;

                    return new UserProfileExtras.Persisted
                    {
                        Id = u.Id,
                        SequenceNumber = u.SequenceNumber,
                        Nome = u.Nome,
                        Cognome = u.Cognome,
                        Ruolo = u.Ruolo,
                        DataAssunzione = u.DataAssunzione,
                        OreContrattoSettimanali = oreSett,
                        CompensoOrarioBase = u.CompensoOrarioBase,
                        CompensoOrarioExtra = u.CompensoOrarioExtra,
                        OrarioIngresso1 = u.OrarioIngresso1,
                        OrarioUscita1 = u.OrarioUscita1,
                        OrarioIngresso2 = u.OrarioIngresso2,
                        OrarioUscita2 = u.OrarioUscita2,
                        OreGiornalierePreviste = oreGiorno,
                        GiorniLavorativiSettimana = giorni
                    };
                }).ToList();

                string json = JsonSerializer.Serialize(persisted, options);
                File.WriteAllText(jsonPath, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore durante il salvataggio di utenti.json: {ex.Message}");
            }

            // Esportazione CSV (solo per compatibilità / eventuali strumenti esterni)
            try
            {
                var lines = _users.Select(u => string.Join(",", new[]
                {
            u.Id,
            u.SequenceNumber.ToString(System.Globalization.CultureInfo.InvariantCulture),
            u.Nome,
            u.Cognome,
            u.Ruolo,
            u.DataAssunzione.ToString("yyyy-MM-dd"),
            u.OreContrattoSettimanali.ToString(System.Globalization.CultureInfo.InvariantCulture),
            u.CompensoOrarioBase.ToString(System.Globalization.CultureInfo.InvariantCulture),
            u.CompensoOrarioExtra.ToString(System.Globalization.CultureInfo.InvariantCulture),
            u.OrarioIngresso1 ?? string.Empty,
            u.OrarioUscita1 ?? string.Empty,
            u.OrarioIngresso2 ?? string.Empty,
            u.OrarioUscita2 ?? string.Empty
        }));

                File.WriteAllLines(csvPath, lines);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore durante l'aggiornamento di utenti.csv: {ex.Message}");
            }
        }


        /// <summary>
        /// Carica le festività da festivita.csv e aggiorna la griglia dedicata.
        /// </summary>
        private void LoadHolidays()
        {
            _holidays = new List<Holiday>();

            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            string path = Path.Combine(_csvFolder, "festivita.csv");
            if (!File.Exists(path))
                return;

            var repo = new CsvRepository();

            foreach (var fields in repo.Load(path))
            {
                try
                {
                    var h = new Holiday
                    {
                        Data = DateTime.TryParse(fields.ElementAtOrDefault(0), out var d) ? d : DateTime.MinValue,
                        Descrizione = fields.ElementAtOrDefault(1)
                    };
                    _holidays.Add(h);
                }
                catch
                {
                    // ignora riga malformata
                }
            }

            var grid = this.FindName("HolidayGrid") as System.Windows.Controls.DataGrid;
            if (grid != null)
            {
                grid.ItemsSource = null;
                grid.ItemsSource = _holidays;
            }
        }

        /// <summary>
        /// Carica le impostazioni straordinari dal file parametri_straordinari.csv e aggiorna lo slider.
        /// </summary>
        private void LoadSettings()
        {
            // Unica fonte di verità: App.ParametriGlobali (parametri_straordinari.json)
            var p = App.ParametriGlobali;
            if (p == null)
                return;

            int snapped = SnapOvertimeMinutes(p.SogliaMinutiStraordinario);

            // Slider + label
            if (FindName("OvertimeSlider") is System.Windows.Controls.Slider slider)
                slider.Value = snapped;

            if (FindName("OvertimeValue") is System.Windows.Controls.TextBlock valueLabel)
                valueLabel.Text = $"{snapped} minuti";

            // Weekend come festivo
            if (FindName("SaturdayCheck") is System.Windows.Controls.CheckBox sat)
                sat.IsChecked = p.GiorniSempreFestivi?.Any(x => x == DayOfWeek.Saturday) == true;

            if (FindName("SundayCheck") is System.Windows.Controls.CheckBox sun)
                sun.IsChecked = p.GiorniSempreFestivi?.Any(x => x == DayOfWeek.Sunday) == true;

            RefreshCustomHolidayList();
        }

        private static int SnapOvertimeMinutes(int raw)
        {
            // Valori ammessi: 0 / 10 / 15 / 30
            int[] allowed = { 0, 10, 15, 30 };
            int best = allowed[0];
            int bestDist = int.MaxValue;
            foreach (var a in allowed)
            {
                int d = Math.Abs(raw - a);
                if (d < bestDist)
                {
                    best = a;
                    bestDist = d;
                }
            }
            return best;
        }

        private void RefreshCustomHolidayList()
        {
            if (FindName("CustomHolidayList") is not System.Windows.Controls.ItemsControl list)
                return;

            var p = App.ParametriGlobali;
            var dates = (p?.FestivitaAggiuntive ?? new List<DateTime>())
                .Select(d => d.Date)
                .Distinct()
                .OrderBy(d => d)
                .ToList();

            var items = new List<System.Windows.FrameworkElement>();

            foreach (var dt in dates)
            {
                var sp = new System.Windows.Controls.StackPanel
                {
                    Orientation = System.Windows.Controls.Orientation.Horizontal,
                    Margin = new Thickness(0, 2, 0, 2)
                };

                sp.Children.Add(new System.Windows.Controls.TextBlock
                {
                    Text = dt.ToString("dd/MM/yyyy"),
                    Foreground = System.Windows.Media.Brushes.White,
                    Width = 120
                });

                var btn = new System.Windows.Controls.Button
                {
                    Content = "Rimuovi",
                    Tag = dt,
                    Width = 80,
                    Margin = new Thickness(10, 0, 0, 0)
                };
                btn.Click += RemoveCustomHolidayButton_Click;
                sp.Children.Add(btn);

                items.Add(sp);
            }

            list.ItemsSource = items;
        }

        /// <summary>
        /// Gestisce il click sui pulsanti del menu laterale e cambia tab a seconda del Tag.
        /// </summary>
        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn && btn.Tag != null)
            {
                if (int.TryParse(btn.Tag.ToString(), out int index))
                {
                    var tab = this.FindName("MainTabs") as System.Windows.Controls.TabControl;
                    if (tab != null)
                    {
                        tab.SelectedIndex = index;
                    }
                }
            }
        }

        /// <summary>
        /// Minimizza la finestra.
        /// </summary>
        private void Min_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        /// <summary>
        /// Chiude la finestra.
        /// </summary>
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Aggiunge un nuovo utente tramite AddUserWindow, aggiorna la lista _users
        /// e salva subito su utenti.json + utenti.csv.
        /// </summary>
        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella dati (CSV/JSON).");
                return;
            }

            try
            {
                var dlg = new AddUserWindow(_csvFolder)
                {
                    Owner = this
                };

                bool? result = dlg.ShowDialog();

                if (result == true && dlg.User != null)
                {
                    _users.Add(dlg.User);

                    // Salvataggio su JSON + CSV
                    SaveUsers();

                    // Aggiorna griglia
                    var grid = this.FindName("UsersGrid") as DataGrid;
                    if (grid != null)
                    {
                        grid.ItemsSource = null;
                        grid.ItemsSource = _users;
                    }

                    // Aggiorna combo report
                    var combo = this.FindName("UserSelectorReport") as ComboBox;
                    if (combo != null)
                    {
                        combo.ItemsSource = null;
                        combo.ItemsSource = _users;
                    }

                    MessageBox.Show("Utente aggiunto con successo");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore durante l'aggiunta dell'utente: {ex.Message}");
            }
        }



        /// <summary>
        /// Aggiunge una festività chiedendo data e descrizione e salva su festivita.csv.
        /// </summary>
        private void AddHoliday_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV");
                return;
            }

            try
            {
                string dataStr = Interaction.InputBox("Data (YYYY-MM-DD):", "Nuova festività", DateTime.Now.ToString("yyyy-MM-dd"));
                if (!DateTime.TryParse(dataStr, out var dt))
                {
                    MessageBox.Show("Data non valida");
                    return;
                }

                string descrizione = Interaction.InputBox("Descrizione:", "Nuova festività", "");

                string line = string.Join(",", new[] { dt.ToString("yyyy-MM-dd"), descrizione });

                string path = Path.Combine(_csvFolder, "festivita.csv");
                File.AppendAllText(path, line + Environment.NewLine);

                LoadHolidays();
                MessageBox.Show("Festività aggiunta con successo");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore durante l'aggiunta della festività: {ex.Message}");
            }
        }

        /// <summary>
        /// Aggiorna la soglia dei minuti straordinari quando lo slider cambia e salva il file.
        /// </summary>
        private void OvertimeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_isSnappingOvertimeSlider)
                return;

            int raw = (int)Math.Round(e.NewValue);
            int snapped = SnapOvertimeMinutes(raw);

            // Forza lo slider su uno dei valori ammessi
            if (snapped != raw && sender is System.Windows.Controls.Slider slider)
            {
                _isSnappingOvertimeSlider = true;
                slider.Value = snapped;
                _isSnappingOvertimeSlider = false;
            }

            if (FindName("OvertimeValue") is System.Windows.Controls.TextBlock label)
                label.Text = $"{snapped} minuti";

            // Aggiorna sempre i parametri globali e salva subito su JSON
            if (App.ParametriGlobali != null)
            {
                App.ParametriGlobali.SogliaMinutiStraordinario = snapped;
                App.SalvaParametriGlobali();
            }
        }

        private void WeekendCheck_Changed(object sender, RoutedEventArgs e)
        {
            if (App.ParametriGlobali == null) return;

            var list = (App.ParametriGlobali.GiorniSempreFestivi ?? new List<DayOfWeek>())
                .ToList();

            void SetDay(DayOfWeek day, bool enabled)
            {
                list.RemoveAll(x => x == day);
                if (enabled) list.Add(day);
            }

            bool satOn = (FindName("SaturdayCheck") is System.Windows.Controls.CheckBox sat && sat.IsChecked == true);
            bool sunOn = (FindName("SundayCheck") is System.Windows.Controls.CheckBox sun && sun.IsChecked == true);

            SetDay(DayOfWeek.Saturday, satOn);
            SetDay(DayOfWeek.Sunday, sunOn);

            App.ParametriGlobali.GiorniSempreFestivi = list;
            App.SalvaParametriGlobali();
        }

        private void AddCustomHolidayButton_Click(object sender, RoutedEventArgs e)
        {
            if (App.ParametriGlobali == null) return;
            if (FindName("CustomHolidayPicker") is not System.Windows.Controls.DatePicker picker || picker.SelectedDate == null)
            {
                MessageBox.Show("Seleziona una data.");
                return;
            }

            var dt = picker.SelectedDate.Value.Date;
            App.ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();

            if (!App.ParametriGlobali.FestivitaAggiuntive.Any(x => x.Date == dt))
                App.ParametriGlobali.FestivitaAggiuntive.Add(dt);

            App.SalvaParametriGlobali();
            RefreshCustomHolidayList();
        }

        private void RemoveCustomHolidayButton_Click(object sender, RoutedEventArgs e)
        {
            if (App.ParametriGlobali == null) return;
            if (sender is not System.Windows.Controls.Button btn || btn.Tag is not DateTime dt)
                return;

            if (App.ParametriGlobali.FestivitaAggiuntive != null)
            {
                App.ParametriGlobali.FestivitaAggiuntive = App.ParametriGlobali.FestivitaAggiuntive
                    .Where(x => x.Date != dt.Date)
                    .ToList();
            }

            App.SalvaParametriGlobali();
            RefreshCustomHolidayList();
        }

        private void SaveOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            // Lo slider salva già al volo; qui ci assicuriamo di salvare anche weekend + lista custom.
            WeekendCheck_Changed(sender, e);
            App.SalvaParametriGlobali();
            MessageBox.Show("Parametri salvati.");
        }

        private void CancelOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            // Ricarica i parametri dal JSON
            LoadSettings();
        }

        /// <summary>
        /// Gestione click del bottone di scelta cartella CSV.
        /// </summary>
        private void SelectCsvFolder_Click(object sender, RoutedEventArgs e)
        {
            using (var dialog = new System.Windows.Forms.FolderBrowserDialog())
            {
                var result = dialog.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    _csvFolder = dialog.SelectedPath;
                    CsvPathBox.Text = _csvFolder;

                    // salva nelle impostazioni utente
                    Properties.Settings.Default.CsvFolderPath = _csvFolder;
                    Properties.Settings.Default.Save();

                    // ricarica i dati
                    LoadUsers();
                    LoadHolidays();
                    LoadSettings();
                }
            }
        }

        /// <summary>
        /// Genera i report mensili per gli utenti selezionati (o tutti).
        /// </summary>
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella dei dati.");
                return;
            }

            if (_users == null || _users.Count == 0)
            {
                MessageBox.Show("Non ci sono utenti caricati.");
                return;
            }

            var wnd = new ReportWindow(_csvFolder, _users)
            {
                Owner = this
            };

            wnd.ShowDialog();
        
        }

        /// <summary>
        /// Wrapper per compatibilità con vecchia interfaccia. Chiama GenerateReport_Click.
        /// </summary>
        private void ProcessMonth_Click(object sender, RoutedEventArgs e)
        {
            GenerateReport_Click(sender, e);
        }
    }
}
