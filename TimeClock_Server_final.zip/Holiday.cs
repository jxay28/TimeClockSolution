using System;

namespace TimeClock.Server
{
    /// <summary>
    /// Rappresenta una festività personalizzata o caricata da CSV.
    /// Il Core non espone un tipo Holiday, quindi ne definiamo uno qui.
    /// </summary>
    public class Holiday
    {
        /// <summary>
        /// Data della festività. Viene considerata solo la componente data (anno, mese, giorno).
        /// </summary>
        public DateTime Data { get; set; }

        /// <summary>
        /// Descrizione libera della festività.
        /// </summary>
        public string? Descrizione { get; set; }
    }
}