// NOTE:
// Questo file esiste solo per evitare conflitti di tipo.
//
// Il modello UserProfile ufficiale è in TimeClock.Core.Models (assembly TimeClock.Core).
// In passato qui c'era una seconda definizione di UserProfile che causava:
//   - conflitto di tipo (UserProfile duplicato)
//   - mancanza di proprietà (Id, SequenceNumber, Nome, ...)
//
// Le estensioni richieste (Ore giornaliere previste, Giorni lavorativi settimanali previsti,
// calcolo ore settimanali, ecc.) sono implementate in UserProfileExtras.cs tramite
// extension methods, così non tocchiamo il modello nel core.

namespace TimeClock.Server
{
    // Intenzionalmente vuoto.
}
