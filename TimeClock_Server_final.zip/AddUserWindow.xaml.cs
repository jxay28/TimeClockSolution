using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using TimeClock.Core.Models;
using TimeClock.Core.Services;
using System.Globalization;

namespace TimeClock.Server
{
    public partial class AddUserWindow : Window
    {
        private readonly string _dataFolder;
        public UserProfile? User { get; private set; }

        public AddUserWindow(string csvFolder)
        {
            InitializeComponent();
            _dataFolder = csvFolder;

            // ID univoco
            IdBox.Text = Guid.NewGuid().ToString();
            AssunzionePicker.SelectedDate = DateTime.Now;

            LoadSequentialNumber();

            // valori di default per i turni
            Ingresso1Combo.SelectedIndex = 0;
            Uscita1Combo.SelectedIndex = 0;
            Ingresso2Combo.SelectedIndex = 0;
            Uscita2Combo.SelectedIndex = 0;

            // Default nuovi campi
            OreGiornaliereBox.Text = "8";
            GiorniLavorativiCombo.SelectedIndex = 4; // 5 giorni

            OreGiornaliereBox.TextChanged += (_, __) => UpdateOreSettimanali();
            GiorniLavorativiCombo.SelectionChanged += (_, __) => UpdateOreSettimanali();
            UpdateOreSettimanali();
        }

        /// <summary>
        /// Calcola il prossimo numero sequenziale guardando prima utenti.json,
        /// se non esiste prova a leggere utenti.csv per migrazione.
        /// </summary>
        private void LoadSequentialNumber()
        {
            int next = 0;

            if (string.IsNullOrWhiteSpace(_dataFolder))
            {
                SeqNumberBox.Text = next.ToString();
                return;
            }

            string jsonPath = Path.Combine(_dataFolder, "utenti.json");
            string csvPath = Path.Combine(_dataFolder, "utenti.csv");

            // 1) JSON master
            if (File.Exists(jsonPath))
            {
                try
                {
                    string json = File.ReadAllText(jsonPath);

                    // Nuovo formato (Persisted) con campi extra
                    var persisted = JsonSerializer.Deserialize<List<UserProfileExtras.Persisted>>(json);
                    if (persisted != null && persisted.Any())
                    {
                        next = persisted.Max(u => u.SequenceNumber) + 1;
                    }
                    else
                    {
                        // Compatibilità vecchio formato
                        var list = JsonSerializer.Deserialize<List<UserProfile>>(json) ?? new List<UserProfile>();
                        if (list.Any())
                            next = list.Max(u => u.SequenceNumber) + 1;
                    }
                }
                catch
                {
                    // in caso di problemi, next resta 0 e si passerà a CSV
                }
            }
            // 2) fallback CSV (prima migrazione)
            else if (File.Exists(csvPath))
            {
                try
                {
                    var repo = new CsvRepository();
                    var nums = repo.Load(csvPath)
                                   .Select(r => r.ElementAtOrDefault(1))
                                   .Where(v => !string.IsNullOrWhiteSpace(v) && int.TryParse(v, out _))
                                   .Select(v => int.Parse(v!))
                                   .ToList();
                    if (nums.Any())
                        next = nums.Max() + 1;
                }
                catch
                {
                    // se fallisce, resta 0
                }
            }

            SeqNumberBox.Text = next.ToString();
        }

        private void UpdateOreSettimanali()
        {
            // Ore giornaliere
            if (!double.TryParse(
                    OreGiornaliereBox.Text.Replace(",", "."),
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out var oreGiorno) || oreGiorno < 0)
            {
                OreBox.Text = string.Empty;
                return;
            }

            // Giorni lavorativi
            int giorni = 0;
            if (GiorniLavorativiCombo.SelectedItem is ComboBoxItem item &&
                int.TryParse(item.Content?.ToString(), out var g))
            {
                giorni = g;
            }

            if (giorni <= 0)
            {
                OreBox.Text = string.Empty;
                return;
            }

            var oreSett = oreGiorno * giorni;
            OreBox.Text = oreSett.ToString(CultureInfo.InvariantCulture);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            // Data assunzione
            DateTime dataAss;
            if (AssunzionePicker.SelectedDate == null)
            {
                MessageBox.Show("Data non selezionata. Impostata la data di oggi.");
                dataAss = DateTime.Today;
            }
            else
            {
                dataAss = AssunzionePicker.SelectedDate.Value;
            }

            // Numero sequenziale
            if (!int.TryParse(SeqNumberBox.Text, out int seq))
            {
                MessageBox.Show("Numero sequenziale non valido.");
                return;
            }

            // Ore giornaliere previste
            if (!double.TryParse(
                    OreGiornaliereBox.Text.Replace(",", "."),
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out var oreGiorno) || oreGiorno <= 0)
            {
                MessageBox.Show("Le ore giornaliere previste devono essere un numero.");
                return;
            }

            // Giorni lavorativi settimanali
            int giorniLav = 0;
            if (GiorniLavorativiCombo.SelectedItem is ComboBoxItem giorniItem &&
                int.TryParse(giorniItem.Content?.ToString(), out var gg))
            {
                giorniLav = gg;
            }
            if (giorniLav < 1 || giorniLav > 7)
            {
                MessageBox.Show("Selezionare i giorni lavorativi settimanali (1-7).");
                return;
            }

            var oreSett = oreGiorno * giorniLav;

            // Salario base
            if (!decimal.TryParse(
                    SalarioBaseBox.Text.Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out var salarioBase))
            {
                MessageBox.Show("Il salario base deve essere un numero.");
                return;
            }

            // Salario extra
            if (!decimal.TryParse(
                    SalarioExtraBox.Text.Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out var salarioExtra))
            {
                MessageBox.Show("Il salario extra deve essere un numero.");
                return;
            }

            // Orari previsti
            string ingresso1 = (Ingresso1Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;
            string uscita1 = (Uscita1Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;
            string ingresso2 = (Ingresso2Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;
            string uscita2 = (Uscita2Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;

            if (string.IsNullOrWhiteSpace(ingresso1) || string.IsNullOrWhiteSpace(uscita1))
            {
                MessageBox.Show("Inserire almeno l'orario ingresso/uscita previsto 1.");
                return;
            }

            // CREAZIONE OGGETTO UTENTE COMPLETO
            User = new UserProfile
            {
                Id = IdBox.Text,
                SequenceNumber = seq,
                Nome = NomeBox.Text.Trim(),
                Cognome = CognomeBox.Text.Trim(),
                Ruolo = RuoloBox.Text.Trim(),
                DataAssunzione = dataAss,
                OreContrattoSettimanali = oreSett,
                CompensoOrarioBase = salarioBase,
                CompensoOrarioExtra = salarioExtra,
                OrarioIngresso1 = ingresso1,
                OrarioUscita1 = uscita1,
                OrarioIngresso2 = ingresso2,
                OrarioUscita2 = uscita2
            };

            // Salva i campi extra (non presenti in TimeClock.Core)
            User.SetOreGiornalierePreviste(oreGiorno);
            User.SetGiorniLavorativiSettimana(giorniLav);

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
