using Microsoft.VisualBasic;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using TimeClock.Core.Models;
using TimeClock.Core.Services;

namespace TimeClock.Server
{
    public partial class ReportWindow : Window
    {
        private readonly string _csvFolder;
        private readonly List<UserProfile> _users;
        private readonly CsvRepository _repo = new CsvRepository();

        private HashSet<DateTime> _festiviDaCsv = new HashSet<DateTime>();
        private HashSet<DateTime> _festiviManuali = new HashSet<DateTime>();
        private string _festiviManualiPath = string.Empty;

        private UserProfile? _currentUser;
        private int _currentMonth;
        private int _currentYear;

        private static readonly CultureInfo ItCulture = CultureInfo.GetCultureInfo("it-IT");

        public ReportWindow(string csvFolder, List<UserProfile> users)
        {
            InitializeComponent();

            _csvFolder = csvFolder;
            _users = users ?? new List<UserProfile>();

            UserCombo.ItemsSource = _users;
            MonthCombo.SelectedIndex = DateTime.Now.Month - 1;

            _currentYear = DateTime.Now.Year;

            CaricaFestivitaDaCsv();
        }

        private void CaricaFestivitaDaCsv()
        {
            _festiviDaCsv.Clear();

            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            string path = Path.Combine(_csvFolder, "festivita.csv");
            if (!File.Exists(path))
                return;

            try
            {
                foreach (var row in _repo.Load(path))
                {
                    if (row.Length < 1) continue;
                    if (DateTime.TryParse(row[0], out var dt))
                        _festiviDaCsv.Add(dt.Date);
                }
            }
            catch
            {
                // Se il file è malformato non blocchiamo l'interfaccia.
            }
        }

        private void CaricaFestiviManuali(UserProfile user)
        {
            _festiviManuali.Clear();

            _festiviManualiPath = Path.Combine(_csvFolder, $"festivi_override_{user.Id}.json");
            if (!File.Exists(_festiviManualiPath))
                return;

            try
            {
                var list = JsonSerializer.Deserialize<List<DateTime>>(File.ReadAllText(_festiviManualiPath)) ?? new List<DateTime>();
                foreach (var d in list)
                    _festiviManuali.Add(d.Date);
            }
            catch
            {
                // Ignora file rovinato.
            }
        }

        private void SalvaFestiviManuali()
        {
            if (string.IsNullOrWhiteSpace(_festiviManualiPath))
                return;

            try
            {
                var list = _festiviManuali.OrderBy(d => d).ToList();
                File.WriteAllText(_festiviManualiPath, JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch
            {
                // Non blocchiamo l'app se non riesce a salvare.
            }
        }

        private void CaricaReport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder) || !Directory.Exists(_csvFolder))
            {
                MessageBox.Show("Seleziona prima una cartella dati valida.");
                return;
            }

            if (UserCombo.SelectedItem is not UserProfile user)
            {
                MessageBox.Show("Seleziona un utente.");
                return;
            }
            if (MonthCombo.SelectedIndex < 0)
            {
                MessageBox.Show("Seleziona un mese.");
                return;
            }

            _currentUser = user;
            _currentMonth = MonthCombo.SelectedIndex + 1;
            _currentYear = DateTime.Now.Year;

            CaricaFestiviManuali(user);

            string filePath = Path.Combine(_csvFolder, $"timbrature_{user.Id}.csv");
            var allEntries = new List<TimeCardEntry>();

            if (File.Exists(filePath))
            {
                foreach (var row in _repo.Load(filePath))
                {
                    if (row.Length < 2) continue;
                    if (!DateTime.TryParse(row[0], out var dt)) continue;

                    PunchType tipo;
                    if (!Enum.TryParse(row[1], true, out tipo))
                        tipo = PunchType.Entrata;

                    allEntries.Add(new TimeCardEntry
                    {
                        UserId = user.Id,
                        DataOra = dt,
                        Tipo = tipo
                    });
                }
            }

            // Filtra mese/anno selezionati
            var entriesMese = allEntries
                .Where(x => x.DataOra.Year == _currentYear && x.DataOra.Month == _currentMonth)
                .OrderBy(x => x.DataOra)
                .ToList();

            int daysInMonth = DateTime.DaysInMonth(_currentYear, _currentMonth);
            var reportRows = new List<ReportRow>(daysInMonth);

            for (int day = 1; day <= daysInMonth; day++)
            {
                var data = new DateTime(_currentYear, _currentMonth, day);
                var dayEntries = entriesMese.Where(x => x.DataOra.Date == data.Date).OrderBy(x => x.DataOra).ToList();

                var coppie = CostruisciCoppie(dayEntries);
                (DateTime Ingresso, DateTime Uscita)? c1 = coppie.Count > 0 ? coppie[0] : null;
                (DateTime Ingresso, DateTime Uscita)? c2 = coppie.Count > 1 ? coppie[1] : null;

                var row = new ReportRow
                {
	                    Giorno = day,
                    Data = data.ToString("dd/MM/yyyy"),
                    Entrata1 = c1?.Ingresso.ToString("HH:mm") ?? "",
                    Uscita1 = c1?.Uscita.ToString("HH:mm") ?? "",
                    Entrata2 = c2?.Ingresso.ToString("HH:mm") ?? "",
                    Uscita2 = c2?.Uscita.ToString("HH:mm") ?? ""
                };

                CalcolaTotaliRiga(row, data, user, c1, c2);
                reportRows.Add(row);
            }

            ReportGrid.ItemsSource = reportRows;

            // Nel XAML non esiste un controllo "ReportTitle".
            // Usiamo il titolo della finestra (anche se la finestra è senza bordo).
            this.Title = $"Report di {user.FullName} - {_currentMonth:D2}/{_currentYear:D4}";

            AggiornaTotali();
        }

        private static List<(DateTime Ingresso, DateTime Uscita)> CostruisciCoppie(List<TimeCardEntry> entries)
        {
            var result = new List<(DateTime Ingresso, DateTime Uscita)>();
            DateTime? currentIn = null;

            foreach (var entry in entries.OrderBy(x => x.DataOra))
            {
                if (entry.Tipo == PunchType.Entrata)
                {
                    currentIn = entry.DataOra;
                    continue;
                }

                if (entry.Tipo == PunchType.Uscita && currentIn.HasValue)
                {
                    result.Add((currentIn.Value, entry.DataOra));
                    currentIn = null;
                }
            }

            return result;
        }

        private void ReportGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (_currentUser == null)
                return;

            // Aspetta che la cella committi il valore (soprattutto per le CheckBox)
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (e.Row?.Item is not ReportRow row)
                    return;

                if (!TryParseRowDate(row, out var data))
                    return;

                // Aggiorna override manuale "Festivo" (solo se non è festivo automatico)
                bool autoFestivo = IsGiornoFestivoAuto(data);
                if (!autoFestivo)
                {
                    if (row.IsFestivo)
                        _festiviManuali.Add(data.Date);
                    else
                        _festiviManuali.Remove(data.Date);
                    SalvaFestiviManuali();
                }

                var c1 = ParseCoppiaDaRiga(data, row.Entrata1, row.Uscita1);
                var c2 = ParseCoppiaDaRiga(data, row.Entrata2, row.Uscita2);
                CalcolaTotaliRiga(row, data, _currentUser, c1, c2);

                AggiornaTotali();
                ReportGrid.Items.Refresh();
            }), DispatcherPriority.Background);
        }

        private static bool TryParseRowDate(ReportRow row, out DateTime data)
        {
            data = default;
            if (row == null) return false;
            return DateTime.TryParseExact(row.Data?.Trim(), "dd/MM/yyyy", ItCulture, DateTimeStyles.None, out data);
        }

        private (DateTime Ingresso, DateTime Uscita)? ParseCoppiaDaRiga(DateTime giorno, string entrata, string uscita)
        {
            if (!TryParseTime(entrata, out var tIn) || !TryParseTime(uscita, out var tOut))
                return null;

            DateTime inDt = giorno.Date.Add(tIn);
            DateTime outDt = giorno.Date.Add(tOut);
            if (outDt < inDt)
                outDt = outDt.AddDays(1);

            return (inDt, outDt);
        }

        private static bool TryParseTime(string value, out TimeSpan ts)
        {
            ts = default;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            string v = value.Trim().Replace('.', ':');

            // accetta "8:00" e "08:00"
            return TimeSpan.TryParseExact(v, new[] { "h\\:mm", "hh\\:mm" }, CultureInfo.InvariantCulture, out ts)
                || TimeSpan.TryParse(v, CultureInfo.InvariantCulture, out ts)
                || TimeSpan.TryParse(v, ItCulture, out ts);
        }

        private int GetBloccoMinuti()
        {
            int raw = App.ParametriGlobali?.SogliaMinutiStraordinario ?? 0;

            // Ammessi: 0, 15, 30
            if (raw <= 0) return 0;
            if (raw < 23) return 15;
            return 30;
        }

        private static DateTime RoundUpToBlock(DateTime dt, int blockMinutes)
        {
            if (blockMinutes <= 0)
                return dt;

            int totalMinutes = dt.Hour * 60 + dt.Minute;
            int mod = totalMinutes % blockMinutes;
            if (mod == 0)
                return dt;

            int rounded = totalMinutes + (blockMinutes - mod);
            return dt.Date.AddMinutes(rounded);
        }

        private static DateTime RoundDownToBlock(DateTime dt, int blockMinutes)
        {
            if (blockMinutes <= 0)
                return dt;

            int totalMinutes = dt.Hour * 60 + dt.Minute;
            int rounded = totalMinutes - (totalMinutes % blockMinutes);
            return dt.Date.AddMinutes(rounded);
        }

        private TimeSpan CalcolaDurataRiconosciuta(DateTime ingresso, DateTime uscita)
        {
            if (uscita <= ingresso)
                return TimeSpan.Zero;

            int block = GetBloccoMinuti();
            if (block <= 0)
                return uscita - ingresso;

            DateTime start = RoundUpToBlock(ingresso, block);
            DateTime end = RoundDownToBlock(uscita, block);
            if (end <= start)
                return TimeSpan.Zero;

            return end - start;
        }

        private static string FormatDurata(TimeSpan ts)
        {
            if (ts <= TimeSpan.Zero)
                return "00:00";

            int ore = (int)Math.Floor(ts.TotalHours);
            int minuti = ts.Minutes;
            return $"{ore:00}:{minuti:00}";
        }

        private bool IsGiornoFestivoAuto(DateTime data)
        {
            // 1) Giorni sempre festivi (sabato/domenica selezionabili)
            var p = App.ParametriGlobali;
            if (p?.GiorniSempreFestivi != null && p.GiorniSempreFestivi.Contains(data.DayOfWeek))
                return true;

            // fallback prudente: se lista nulla/vuota, considera comunque sabato e domenica festivi
            if (p?.GiorniSempreFestivi == null || p.GiorniSempreFestivi.Count == 0)
            {
                if (data.DayOfWeek == DayOfWeek.Saturday || data.DayOfWeek == DayOfWeek.Sunday)
                    return true;
            }

            // 2) Festività ricorrenti (mese/giorno)
            if (p?.FestivitaRicorrenti != null && p.FestivitaRicorrenti.Any(f => f.Mese == data.Month && f.Giorno == data.Day))
                return true;

            // 3) Festività aggiuntive (date specifiche)
            if (p?.FestivitaAggiuntive != null && p.FestivitaAggiuntive.Any(d => d.Date == data.Date))
                return true;

            // 4) Festività da file festivita.csv (legacy)
            if (_festiviDaCsv.Contains(data.Date))
                return true;

            return false;
        }

        private bool IsGiornoFestivoFinal(DateTime data)
        {
            return IsGiornoFestivoAuto(data) || _festiviManuali.Contains(data.Date);
        }

        private double GetOreGiornalierePreviste(UserProfile user)
        {
            int giorni = user.GetGiorniLavorativiSettimana(5);
            if (giorni <= 0) giorni = 5;

            double fallback = (user.OreContrattoSettimanali > 0)
                ? user.OreContrattoSettimanali / giorni
                : 8.0;

            double ore = user.GetOreGiornalierePreviste(fallback);
            return ore > 0 ? ore : fallback;
        }

        private void CalcolaTotaliRiga(
            ReportRow row,
            DateTime data,
            UserProfile user,
            (DateTime Ingresso, DateTime Uscita)? coppia1,
            (DateTime Ingresso, DateTime Uscita)? coppia2)
        {
            var dur1 = coppia1.HasValue ? CalcolaDurataRiconosciuta(coppia1.Value.Ingresso, coppia1.Value.Uscita) : TimeSpan.Zero;
            var dur2 = coppia2.HasValue ? CalcolaDurataRiconosciuta(coppia2.Value.Ingresso, coppia2.Value.Uscita) : TimeSpan.Zero;

            row.Durata1 = dur1.TotalMinutes / 60.0;
            row.Durata2 = dur2.TotalMinutes / 60.0;
            row.Durata1Visual = FormatDurata(dur1);
            row.Durata2Visual = FormatDurata(dur2);

            // Festivo finale = automatico OR override manuale
            bool festivo = IsGiornoFestivoFinal(data);
            row.IsFestivo = festivo;

            double totale = row.Durata1 + row.Durata2;
            row.TotaleOreVisual = ReportRow.ConvertiDecimaliInOre(totale);

            if (festivo)
            {
                row.OreOrdinarie = 0;
                row.OreStraordinarie = totale;
            }
            else
            {
                double oreGiorno = GetOreGiornalierePreviste(user);
                double ord = Math.Min(totale, oreGiorno);
                row.OreOrdinarie = ord;
                row.OreStraordinarie = Math.Max(0, totale - ord);
            }

            row.OreOrdinarieVisual = ReportRow.ConvertiDecimaliInOre(row.OreOrdinarie);
            row.OreStraordinarieVisual = ReportRow.ConvertiDecimaliInOre(row.OreStraordinarie);
        }

        private void AggiornaTotali()
        {
            if (ReportGrid.ItemsSource is not IEnumerable<ReportRow> rows)
            {
	            // I TextBlock corretti nel XAML sono TotOrdinarieText e TotStraordinarieText
	            TotOrdinarieText.Text = "00:00";
	            TotStraordinarieText.Text = "00:00";
                return;
            }

            double ord = rows.Sum(r => r.OreOrdinarie);
            double extra = rows.Sum(r => r.OreStraordinarie);
	        TotOrdinarieText.Text = ReportRow.ConvertiDecimaliInOre(ord);
	        TotStraordinarieText.Text = ReportRow.ConvertiDecimaliInOre(extra);
        }

        private void SalvaModifiche_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser == null)
            {
                MessageBox.Show("Carica prima un report.");
                return;
            }

            if (ReportGrid.ItemsSource is not IEnumerable<ReportRow> rows)
            {
                MessageBox.Show("Nessun dato da salvare.");
                return;
            }

            string filePath = Path.Combine(_csvFolder, $"timbrature_{_currentUser.Id}.csv");

            var keepLines = new List<string>();
            if (File.Exists(filePath))
            {
                foreach (var line in File.ReadAllLines(filePath))
                {
                    var parts = line.Split(',');
                    if (parts.Length < 2) continue;
                    if (!DateTime.TryParse(parts[0].Trim(), out var dt)) continue;

                    if (dt.Year == _currentYear && dt.Month == _currentMonth)
                        continue; // rimpiazziamo tutto il mese

                    keepLines.Add(line);
                }
            }

            var newLines = new List<string>(keepLines);
            foreach (var row in rows)
            {
                if (!TryParseRowDate(row, out var giorno))
                    continue;

                // Coppia 1
                var c1 = ParseCoppiaDaRiga(giorno, row.Entrata1, row.Uscita1);
                if (c1.HasValue)
                {
                    newLines.Add($"{c1.Value.Ingresso:yyyy-MM-dd HH:mm},Entrata");
                    newLines.Add($"{c1.Value.Uscita:yyyy-MM-dd HH:mm},Uscita");
                }

                // Coppia 2
                var c2 = ParseCoppiaDaRiga(giorno, row.Entrata2, row.Uscita2);
                if (c2.HasValue)
                {
                    newLines.Add($"{c2.Value.Ingresso:yyyy-MM-dd HH:mm},Entrata");
                    newLines.Add($"{c2.Value.Uscita:yyyy-MM-dd HH:mm},Uscita");
                }
            }

            // Ordina
            var ordered = newLines
                .Select(l =>
                {
                    var parts = l.Split(',');
                    DateTime.TryParse(parts[0], out var dt);
                    return new { dt, line = l };
                })
                .OrderBy(x => x.dt)
                .Select(x => x.line)
                .ToList();

            File.WriteAllLines(filePath, ordered);

            MessageBox.Show("Modifiche salvate.");
        }

        private void AggiungiTimbratura_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser == null)
            {
                MessageBox.Show("Carica prima un report.");
                return;
            }

            string dataStr = Interaction.InputBox("Inserisci la data (dd/MM/yyyy)", "Nuova timbratura", DateTime.Now.ToString("dd/MM/yyyy"));
            if (!DateTime.TryParseExact(dataStr.Trim(), "dd/MM/yyyy", ItCulture, DateTimeStyles.None, out var data))
            {
                MessageBox.Show("Data non valida.");
                return;
            }

            string oraStr = Interaction.InputBox("Inserisci l'ora (HH:mm)", "Nuova timbratura", DateTime.Now.ToString("HH:mm"));
            if (!TryParseTime(oraStr, out var ora))
            {
                MessageBox.Show("Ora non valida.");
                return;
            }

            string tipoStr = Interaction.InputBox("Tipo (Entrata/Uscita)", "Nuova timbratura", "Entrata");
            if (!Enum.TryParse<PunchType>(tipoStr.Trim(), true, out var tipo))
            {
                MessageBox.Show("Tipo non valido.");
                return;
            }

            DateTime dt = data.Date.Add(ora);

            string filePath = Path.Combine(_csvFolder, $"timbrature_{_currentUser.Id}.csv");
            File.AppendAllLines(filePath, new[] { $"{dt:yyyy-MM-dd HH:mm},{tipo}" });

            MessageBox.Show("Timbratura aggiunta. Ricarica il report.");
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            if (_currentUser == null)
            {
                MessageBox.Show("Carica prima un report.");
                return;
            }
            if (ReportGrid.ItemsSource is not IEnumerable<ReportRow> rows)
            {
                MessageBox.Show("Nessun dato da esportare.");
                return;
            }

            var dlg = new SaveFileDialog
            {
                Filter = "File di testo (*.txt)|*.txt",
                FileName = $"report_{_currentUser.Id}_{_currentYear:D4}-{_currentMonth:D2}.txt"
            };

            if (dlg.ShowDialog() != true)
                return;

            var sb = new StringBuilder();
            sb.AppendLine($"Report: {_currentUser.FullName} - {MonthCombo.SelectedItem} {_currentYear}");
            sb.AppendLine($"Blocco minuti: {GetBloccoMinuti()}");
            sb.AppendLine();
            sb.AppendLine("Data\tEntrata1\tUscita1\tDurata1\tEntrata2\tUscita2\tDurata2\tFestivo\tOrdinarie\tStraordinarie");

            foreach (var r in rows)
            {
                sb.AppendLine($"{r.Data}\t{r.Entrata1}\t{r.Uscita1}\t{r.Durata1Visual}\t{r.Entrata2}\t{r.Uscita2}\t{r.Durata2Visual}\t{r.IsFestivo}\t{r.OreOrdinarieVisual}\t{r.OreStraordinarieVisual}");
            }

            sb.AppendLine();
	            sb.AppendLine($"Totale ordinarie: {TotOrdinarieText.Text}");
	            sb.AppendLine($"Totale straordinarie: {TotStraordinarieText.Text}");

            File.WriteAllText(dlg.FileName, sb.ToString(), Encoding.UTF8);
            MessageBox.Show("Esportazione completata.");
        }

	        // Il XAML usa Click="EsportaTXT_Click".
	        // Manteniamo Export_Click (usato internamente) e forniamo questo alias.
	        private void EsportaTXT_Click(object sender, RoutedEventArgs e)
	        {
	            Export_Click(sender, e);
	        }

        private void EsportaPDF_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Esportazione PDF non ancora implementata in questa versione.");
        }

        private void Chiudi_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

    public class ReportRow
    {
	    // Visualizzato nella prima colonna del report ("Giorno")
	    public int Giorno { get; set; }

        public string Data { get; set; } = "";

        public string Entrata1 { get; set; } = "";
        public string Uscita1 { get; set; } = "";
        public double Durata1 { get; set; }
        public string Durata1Visual { get; set; } = "00:00";

        public string Entrata2 { get; set; } = "";
        public string Uscita2 { get; set; } = "";
        public double Durata2 { get; set; }
        public string Durata2Visual { get; set; } = "00:00";

        public bool IsFestivo { get; set; }
        public double OreOrdinarie { get; set; }
        public double OreStraordinarie { get; set; }

        public string TotaleOreVisual { get; set; } = "00:00";
        public string OreOrdinarieVisual { get; set; } = "00:00";
        public string OreStraordinarieVisual { get; set; } = "00:00";

        public static string ConvertiDecimaliInOre(double ore)
        {
            if (ore <= 0)
                return "00:00";

            // Convertiamo in minuti per evitare errori floating.
            int totalMinutes = (int)Math.Round(ore * 60.0, MidpointRounding.AwayFromZero);
            int hh = totalMinutes / 60;
            int mm = totalMinutes % 60;
            return $"{hh:00}:{mm:00}";
        }
    }
}
