using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using TimeClock.Core.Models;
using TimeClock.Core.Services;

namespace TimeClock.Server
{
    public partial class AddUserWindow : Window
    {
        private readonly string _dataFolder;
        public UserProfile? User { get; private set; }

        public AddUserWindow(string csvFolder)
        {
            InitializeComponent();
            _dataFolder = csvFolder;

            // ID univoco
            IdBox.Text = Guid.NewGuid().ToString();
            AssunzionePicker.SelectedDate = DateTime.Now;

            LoadSequentialNumber();

            // valori di default per i turni
            Ingresso1Combo.SelectedIndex = 0;
            Uscita1Combo.SelectedIndex = 0;
            Ingresso2Combo.SelectedIndex = 0;
            Uscita2Combo.SelectedIndex = 0;

            // calcolo automatico ore settimanali
            OreGiornaliereBox.TextChanged += (_, __) => AggiornaOreSettimanali();
            GiorniLavorativiCombo.SelectionChanged += (_, __) => AggiornaOreSettimanali();
            AggiornaOreSettimanali();
        }

        private void AggiornaOreSettimanali()
        {
            double oreGiorno = ParseDoubleOrZero(OreGiornaliereBox.Text);
            int giorni = ParseGiorniLavorativi();
            double oreSett = oreGiorno * giorni;
            OreBox.Text = oreSett.ToString("0.##", CultureInfo.InvariantCulture);
        }

        private static double ParseDoubleOrZero(string? text)
        {
            if (string.IsNullOrWhiteSpace(text)) return 0;
            string normalized = text.Replace(",", ".");
            return double.TryParse(normalized, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : 0;
        }

        private int ParseGiorniLavorativi()
        {
            if (GiorniLavorativiCombo.SelectedItem is ComboBoxItem item &&
                int.TryParse(item.Content?.ToString(), out int giorni) &&
                giorni >= 1 && giorni <= 7)
            {
                return giorni;
            }
            return 5; // default
        }

        /// <summary>
        /// Calcola il prossimo numero sequenziale guardando prima utenti.json,
        /// se non esiste prova a leggere utenti.csv per migrazione.
        /// </summary>
        private void LoadSequentialNumber()
        {
            int next = 0;

            if (string.IsNullOrWhiteSpace(_dataFolder))
            {
                SeqNumberBox.Text = next.ToString();
                return;
            }

            string jsonPath = Path.Combine(_dataFolder, "utenti.json");
            string csvPath = Path.Combine(_dataFolder, "utenti.csv");

            // 1) JSON master
            if (File.Exists(jsonPath))
            {
                try
                {
                    string json = File.ReadAllText(jsonPath);
                    // formato nuovo (DTO persistito con extra)
                    var persisted = JsonSerializer.Deserialize<List<UserProfileExtras.Persisted>>(json);
                    if (persisted != null && persisted.Any())
                    {
                        next = persisted.Max(u => u.SequenceNumber) + 1;
                    }
                    else
                    {
                        // formato legacy (UserProfile puro)
                        var list = JsonSerializer.Deserialize<List<UserProfile>>(json) ?? new List<UserProfile>();
                        if (list.Any())
                            next = list.Max(u => u.SequenceNumber) + 1;
                    }
                }
                catch
                {
                    // in caso di problemi, next resta 0 e si passerà a CSV
                }
            }
            // 2) fallback CSV (prima migrazione)
            else if (File.Exists(csvPath))
            {
                try
                {
                    var repo = new CsvRepository();
                    var nums = repo.Load(csvPath)
                                   .Select(r => r.ElementAtOrDefault(1))
                                   .Where(v => !string.IsNullOrWhiteSpace(v) && int.TryParse(v, out _))
                                   .Select(v => int.Parse(v!))
                                   .ToList();
                    if (nums.Any())
                        next = nums.Max() + 1;
                }
                catch
                {
                    // se fallisce, resta 0
                }
            }

            SeqNumberBox.Text = next.ToString();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            // Data assunzione
            DateTime dataAss;
            if (AssunzionePicker.SelectedDate == null)
            {
                MessageBox.Show("Data non selezionata. Impostata la data di oggi.");
                dataAss = DateTime.Today;
            }
            else
            {
                dataAss = AssunzionePicker.SelectedDate.Value;
            }

            // Numero sequenziale
            if (!int.TryParse(SeqNumberBox.Text, out int seq))
            {
                MessageBox.Show("Numero sequenziale non valido.");
                return;
            }

            // Ore giornaliere previste + giorni lavorativi (da cui derivano le ore settimanali)
            double oreGiornaliere = ParseDoubleOrZero(OreGiornaliereBox.Text);
            if (oreGiornaliere <= 0)
            {
                MessageBox.Show("Le ore previste al giorno devono essere un numero maggiore di 0.");
                return;
            }

            int giorniLavorativi = ParseGiorniLavorativi();
            double oreSettimanali = oreGiornaliere * giorniLavorativi;

            // Salario base
            if (!decimal.TryParse(
                    SalarioBaseBox.Text.Replace(",", "."),
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out var salarioBase))
            {
                MessageBox.Show("Il salario base deve essere un numero.");
                return;
            }

            // Salario extra
            if (!decimal.TryParse(
                    SalarioExtraBox.Text.Replace(",", "."),
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out var salarioExtra))
            {
                MessageBox.Show("Il salario extra deve essere un numero.");
                return;
            }

            // Orari previsti
            string ingresso1 = (Ingresso1Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;
            string uscita1 = (Uscita1Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;
            string ingresso2 = (Ingresso2Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;
            string uscita2 = (Uscita2Combo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;

            if (string.IsNullOrWhiteSpace(ingresso1) || string.IsNullOrWhiteSpace(uscita1))
            {
                MessageBox.Show("Inserire almeno l'orario ingresso/uscita previsto 1.");
                return;
            }

            // CREAZIONE OGGETTO UTENTE COMPLETO
            User = new UserProfile
            {
                Id = IdBox.Text,
                SequenceNumber = seq,
                Nome = NomeBox.Text.Trim(),
                Cognome = CognomeBox.Text.Trim(),
                Ruolo = RuoloBox.Text.Trim(),
                DataAssunzione = dataAss,
                OreContrattoSettimanali = oreSettimanali,
                CompensoOrarioBase = salarioBase,
                CompensoOrarioExtra = salarioExtra,
                OrarioIngresso1 = ingresso1,
                OrarioUscita1 = uscita1,
                OrarioIngresso2 = ingresso2,
                OrarioUscita2 = uscita2
            };

            // Extra (non presenti in TimeClock.Core): li agganciamo in runtime e li persistiamo tramite DTO
            User.SetOreGiornalierePreviste(oreGiornaliere);
            User.SetGiorniLavorativiSettimana(giorniLavorativi);

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
