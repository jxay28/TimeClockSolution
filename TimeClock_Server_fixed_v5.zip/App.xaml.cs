using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class App : Application
    {
        public static ParametriStraordinari ParametriGlobali = new ParametriStraordinari();

        // Percorso completo del file parametri (può stare nella cartella CSV scelta dall'utente)
        private static string _parametriPath = "parametri_straordinari.json";

        private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true,
        };

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Scriviamo/leggiamo enum come stringa (Saturday/Sunday ecc.) per avere un JSON leggibile.
            if (_jsonOptions.Converters.OfType<JsonStringEnumConverter>().FirstOrDefault() == null)
                _jsonOptions.Converters.Add(new JsonStringEnumConverter());

            // Default: prova a leggere dal path di default (cartella app).
            // La MainWindow chiamerà poi ImpostaCartellaDati(...) quando l'utente sceglie la cartella CSV.
            CaricaParametriGlobali();
        }

        /// <summary>
        /// Imposta la cartella "dati" (tipicamente la cartella CSV condivisa) e ricarica i parametri globali.
        /// </summary>
        public static void ImpostaCartellaDati(string? folder)
        {
            if (!string.IsNullOrWhiteSpace(folder) && Directory.Exists(folder))
                _parametriPath = Path.Combine(folder, "parametri_straordinari.json");
            else
                _parametriPath = "parametri_straordinari.json";

            CaricaParametriGlobali();
        }

        public static void CaricaParametriGlobali()
        {
            try
            {
                if (File.Exists(_parametriPath))
                {
                    ParametriGlobali = JsonSerializer.Deserialize<ParametriStraordinari>(
                        File.ReadAllText(_parametriPath), _jsonOptions) ?? new ParametriStraordinari();
                }
                else
                {
                    ParametriGlobali = new ParametriStraordinari();
                    SalvaParametriGlobali();
                }
            }
            catch
            {
                // In caso di JSON rotto/non leggibile: ripartiamo da default (ma non crashiamo l'app)
                ParametriGlobali = new ParametriStraordinari();
            }

            // Normalizzazione: liste non null
            ParametriGlobali.GiorniSempreFestivi ??= new List<DayOfWeek>();
            ParametriGlobali.FestivitaRicorrenti ??= new List<(int Mese, int Giorno)>();
            ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();
        }

        public static void SalvaParametriGlobali()
        {
            try
            {
                // Normalizzazione: liste non null
                ParametriGlobali.GiorniSempreFestivi ??= new List<DayOfWeek>();
                ParametriGlobali.FestivitaRicorrenti ??= new List<(int Mese, int Giorno)>();
                ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();

                File.WriteAllText(_parametriPath,
                    JsonSerializer.Serialize(ParametriGlobali, _jsonOptions));
            }
            catch
            {
                // non blocchiamo l'app per un errore di I/O
            }
        }
    }
}
