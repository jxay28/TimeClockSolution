using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using TimeClock.Core.Models;
using TimeClock.Core.Services;

namespace TimeClock.Server
{
    public partial class MainWindow : Window
    {
        private string _csvFolder = string.Empty;
        private List<UserProfile> _users = new();
        private List<Holiday> _holidays = new();

        private bool _isSnappingOvertimeSlider;

        // Mappa festività nazionali a data fissa (ricorrenti)
        private static readonly Dictionary<string, (int Mese, int Giorno)> _festivitaNazionaliFisse = new()
        {
            { "1 gennaio - Capodanno", (1, 1) },
            { "6 gennaio - Epifania", (1, 6) },
            { "25 aprile - Liberazione", (4, 25) },
            { "1 maggio - Festa dei lavoratori", (5, 1) },
            { "2 giugno - Festa della Repubblica", (6, 2) },
            { "15 agosto - Ferragosto", (8, 15) },
            { "1 novembre - Ognissanti", (11, 1) },
            { "8 dicembre - Immacolata Concezione", (12, 8) },
            { "25 dicembre - Natale", (12, 25) },
            { "26 dicembre - Santo Stefano", (12, 26) },
        };

        private const string _checkPasqua = "Pasqua";
        private const string _checkPasquetta = "Lunedì dell'Angelo";

        private readonly List<CheckBox> _checkFestivitaNazionali = new();

        private static readonly JsonSerializerOptions _jsonOptions = new()
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true,
            Converters = { new JsonStringEnumConverter() }
        };

        public MainWindow()
        {
            InitializeComponent();

            HookParametriUIEvents();
            RaccogliCheckboxFestivitaNazionali();

            // Carichiamo la cartella dati
            _csvFolder = Properties.Settings.Default.CsvFolderPath;
            if (!string.IsNullOrWhiteSpace(_csvFolder) && Directory.Exists(_csvFolder))
            {
                CsvPathBox.Text = _csvFolder;

                // Parametri globali: JSON dentro la cartella dati
                App.ImpostaCartellaDati(_csvFolder);

                LoadUsers();
                LoadHolidaysCsv();
            }
            else
            {
                CsvPathBox.Text = "Nessuna cartella selezionata";
                _csvFolder = string.Empty;
            }

            RefreshParametriUIFromGlobal();
        }

        // =============================
        //  Window chrome (titolo)
        // =============================
        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                DragMove();
        }

        private void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string tag && int.TryParse(tag, out int tabIndex))
                MainTabs.SelectedIndex = tabIndex;
        }

        // =============================
        //  Selezione cartella CSV
        // =============================
        private void SelectCsvFolder_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Seleziona la cartella contenente i CSV (utenti, timbrature, parametri)",
                UseDescriptionForTitle = true
            };

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                _csvFolder = dlg.SelectedPath;
                CsvPathBox.Text = _csvFolder;
                Properties.Settings.Default.CsvFolderPath = _csvFolder;
                Properties.Settings.Default.Save();

                App.ImpostaCartellaDati(_csvFolder);

                LoadUsers();
                LoadHolidaysCsv();
                RefreshParametriUIFromGlobal();
            }
        }

        // =============================
        //  Utenti
        // =============================
        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.");
                return;
            }

            var w = new AddUserWindow(_csvFolder) { Owner = this };
            if (w.ShowDialog() == true && w.User != null)
            {
                _users.Add(w.User);
                SaveUsers();
                UsersGrid.ItemsSource = null;
                UsersGrid.ItemsSource = _users;
            }
        }

        private void LoadUsers()
        {
            _users = new List<UserProfile>();

            if (string.IsNullOrWhiteSpace(_csvFolder) || !Directory.Exists(_csvFolder))
            {
                UsersGrid.ItemsSource = _users;
                return;
            }

            string jsonPath = Path.Combine(_csvFolder, "utenti.json");
            string csvPath = Path.Combine(_csvFolder, "utenti.csv");

            // 1) JSON (formato nuovo con campi extra)
            if (File.Exists(jsonPath))
            {
                string json = File.ReadAllText(jsonPath);

                // Proviamo prima il formato Persisted
                try
                {
                    var persisted = JsonSerializer.Deserialize<List<UserProfileExtras.Persisted>>(json, _jsonOptions);
                    if (persisted != null && persisted.Count > 0 && persisted.Any(p => !string.IsNullOrWhiteSpace(p.Id)))
                    {
                        foreach (var p in persisted)
                        {
                            var u = new UserProfile
                            {
                                Id = p.Id,
                                SequenceNumber = p.SequenceNumber,
                                Nome = p.Nome,
                                Cognome = p.Cognome,
                                Ruolo = p.Ruolo,
                                DataAssunzione = p.DataAssunzione,
                                OreContrattoSettimanali = p.OreContrattoSettimanali,
                                CompensoOrarioBase = p.CompensoOrarioBase,
                                CompensoOrarioExtra = p.CompensoOrarioExtra,
                                OrarioIngresso1 = p.OrarioIngresso1,
                                OrarioUscita1 = p.OrarioUscita1,
                                OrarioIngresso2 = p.OrarioIngresso2,
                                OrarioUscita2 = p.OrarioUscita2,
                            };

                            // Extra: ore giornaliere e giorni settimana
                            if (p.OreGiornalierePreviste > 0) u.SetOreGiornalierePreviste(p.OreGiornalierePreviste);
                            if (p.GiorniLavorativiSettimana > 0) u.SetGiorniLavorativiSettimana(p.GiorniLavorativiSettimana);

                            _users.Add(u);
                        }

                        UsersGrid.ItemsSource = _users;
                        return;
                    }
                }
                catch
                {
                    // Ignoriamo e proviamo il formato vecchio
                }

                // Formato vecchio: List<UserProfile>
                try
                {
                    var list = JsonSerializer.Deserialize<List<UserProfile>>(json, _jsonOptions) ?? new List<UserProfile>();
                    _users = list;

                    // Default per i campi extra
                    foreach (var u in _users)
                    {
                        var giorni = 5;
                        var oreG = u.OreContrattoSettimanali > 0 ? u.OreContrattoSettimanali / giorni : 8.0;
                        u.SetGiorniLavorativiSettimana(giorni);
                        u.SetOreGiornalierePreviste(oreG);
                    }

                    UsersGrid.ItemsSource = _users;
                    return;
                }
                catch
                {
                    _users = new List<UserProfile>();
                    UsersGrid.ItemsSource = _users;
                    return;
                }
            }

            // 2) Migrazione CSV -> JSON
            if (File.Exists(csvPath))
            {
                var repo = new CsvRepository();
                foreach (var r in repo.Load(csvPath))
                {
                    // Formato utenti.csv storico:
                    // 0 Id
                    // 1 SequenceNumber
                    // 2 Nome
                    // 3 Cognome
                    // 4 Ruolo
                    // 5 DataAssunzione
                    // 6 OreSettimanali
                    // 7 CompensoBase
                    // 8 CompensoExtra
                    // 9 Ingresso1
                    // 10 Uscita1
                    // 11 Ingresso2
                    // 12 Uscita2

                    if (r.Length < 9) continue;

                    var u = new UserProfile
                    {
                        Id = r.ElementAtOrDefault(0) ?? Guid.NewGuid().ToString(),
                        SequenceNumber = int.TryParse(r.ElementAtOrDefault(1), out var seq) ? seq : 0,
                        Nome = r.ElementAtOrDefault(2) ?? string.Empty,
                        Cognome = r.ElementAtOrDefault(3) ?? string.Empty,
                        Ruolo = r.ElementAtOrDefault(4) ?? string.Empty,
                        DataAssunzione = DateTime.TryParse(r.ElementAtOrDefault(5), out var dt) ? dt : DateTime.Today,
                        OreContrattoSettimanali = double.TryParse((r.ElementAtOrDefault(6) ?? "0").Replace(",", "."), NumberStyles.Any, CultureInfo.InvariantCulture, out var oreSett) ? oreSett : 0,
                        CompensoOrarioBase = decimal.TryParse((r.ElementAtOrDefault(7) ?? "0").Replace(",", "."), NumberStyles.Any, CultureInfo.InvariantCulture, out var cb) ? cb : 0,
                        CompensoOrarioExtra = decimal.TryParse((r.ElementAtOrDefault(8) ?? "0").Replace(",", "."), NumberStyles.Any, CultureInfo.InvariantCulture, out var ce) ? ce : 0,
                        OrarioIngresso1 = r.ElementAtOrDefault(9),
                        OrarioUscita1 = r.ElementAtOrDefault(10),
                        OrarioIngresso2 = r.ElementAtOrDefault(11),
                        OrarioUscita2 = r.ElementAtOrDefault(12),
                    };

                    // Default extra
                    var giorni = 5;
                    var oreG = u.OreContrattoSettimanali > 0 ? u.OreContrattoSettimanali / giorni : 8.0;
                    u.SetGiorniLavorativiSettimana(giorni);
                    u.SetOreGiornalierePreviste(oreG);

                    _users.Add(u);
                }

                SaveUsers();
                UsersGrid.ItemsSource = _users;
                return;
            }

            UsersGrid.ItemsSource = _users;
        }

        private void SaveUsers()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder) || !Directory.Exists(_csvFolder))
                return;

            string jsonPath = Path.Combine(_csvFolder, "utenti.json");
            string csvPath = Path.Combine(_csvFolder, "utenti.csv");

            // Salvataggio JSON (formato Persisted)
            var persisted = _users.Select(u => new UserProfileExtras.Persisted
            {
                Id = u.Id,
                SequenceNumber = u.SequenceNumber,
                Nome = u.Nome,
                Cognome = u.Cognome,
                Ruolo = u.Ruolo,
                DataAssunzione = u.DataAssunzione,
                // Ore settimanali: sempre coerenti con oreGiorno x giorni
                OreContrattoSettimanali = u.CalcolaOreSettimanali(u.OreContrattoSettimanali),
                CompensoOrarioBase = u.CompensoOrarioBase,
                CompensoOrarioExtra = u.CompensoOrarioExtra,
                OrarioIngresso1 = u.OrarioIngresso1,
                OrarioUscita1 = u.OrarioUscita1,
                OrarioIngresso2 = u.OrarioIngresso2,
                OrarioUscita2 = u.OrarioUscita2,
                OreGiornalierePreviste = u.GetOreGiornalierePreviste(0),
                GiorniLavorativiSettimana = u.GetGiorniLavorativiSettimana(0)
            }).ToList();

            File.WriteAllText(jsonPath, JsonSerializer.Serialize(persisted, _jsonOptions));

            // Salviamo anche utenti.csv per compatibilità/legacy
            var lines = new List<string>();
            foreach (var u in persisted)
            {
                lines.Add(string.Join(",", new[]
                {
                    u.Id,
                    u.SequenceNumber.ToString(CultureInfo.InvariantCulture),
                    EscapeCsv(u.Nome),
                    EscapeCsv(u.Cognome),
                    EscapeCsv(u.Ruolo),
                    u.DataAssunzione.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                    u.OreContrattoSettimanali.ToString(CultureInfo.InvariantCulture),
                    u.CompensoOrarioBase.ToString(CultureInfo.InvariantCulture),
                    u.CompensoOrarioExtra.ToString(CultureInfo.InvariantCulture),
                    u.OrarioIngresso1 ?? "",
                    u.OrarioUscita1 ?? "",
                    u.OrarioIngresso2 ?? "",
                    u.OrarioUscita2 ?? "",
                }));
            }
            File.WriteAllLines(csvPath, lines);
        }

        private static string EscapeCsv(string? s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            // Qui teniamo semplice: se c'è una virgola, mettiamo tra apici
            return s.Contains(',') ? $"\"{s.Replace("\"", "\"\"")}\"" : s;
        }

        // =============================
        //  Report
        // =============================
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.");
                return;
            }

            var w = new ReportWindow(_csvFolder, _users) { Owner = this };
            w.ShowDialog();
        }

        // =============================
        //  Festività CSV (tab dedicata)
        // =============================
        private void AddHoliday_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.");
                return;
            }

            string dateStr = Interaction.InputBox("Inserisci la data (es. 2025-12-24)", "Aggiungi festività", "");
            if (!DateTime.TryParse(dateStr, out var dt))
            {
                MessageBox.Show("Data non valida.");
                return;
            }

            string desc = Interaction.InputBox("Descrizione (opzionale)", "Aggiungi festività", "");

	            // Il modello Holiday nel Core usa nomi in italiano (Data / Descrizione)
	            _holidays.Add(new Holiday { Data = dt.Date, Descrizione = desc });
            SaveHolidaysCsv();
            HolidayGrid.ItemsSource = null;
            HolidayGrid.ItemsSource = _holidays;
        }

        private void LoadHolidaysCsv()
        {
            _holidays = new List<Holiday>();

            if (string.IsNullOrWhiteSpace(_csvFolder) || !Directory.Exists(_csvFolder))
            {
                HolidayGrid.ItemsSource = _holidays;
                return;
            }

            string path = Path.Combine(_csvFolder, "festivita.csv");
            if (!File.Exists(path))
            {
                HolidayGrid.ItemsSource = _holidays;
                return;
            }

            var repo = new CsvRepository();
            foreach (var r in repo.Load(path))
            {
                if (r.Length == 0) continue;
                if (!DateTime.TryParse(r[0], out var dt)) continue;
                var desc = r.Length > 1 ? r[1] : string.Empty;
	                _holidays.Add(new Holiday { Data = dt.Date, Descrizione = desc });
            }

            HolidayGrid.ItemsSource = _holidays;
        }

        private void SaveHolidaysCsv()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder) || !Directory.Exists(_csvFolder))
                return;

            string path = Path.Combine(_csvFolder, "festivita.csv");

	            var lines = _holidays
	                .OrderBy(h => h.Data)
	                .Select(h => string.Join(",", h.Data.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), EscapeCsv(h.Descrizione)))
	                .ToList();

            File.WriteAllLines(path, lines);
        }

        // =============================
        //  Parametri Straordinari (GLOBALI)
        // =============================
        private void HookParametriUIEvents()
        {
            // Eventi non dichiarati in XAML (manteniamo il design invariato)
            OvertimeSlider.ValueChanged += OvertimeSlider_ValueChanged;

            SaturdayCheck.Checked += WeekendCheck_Changed;
            SaturdayCheck.Unchecked += WeekendCheck_Changed;
            SundayCheck.Checked += WeekendCheck_Changed;
            SundayCheck.Unchecked += WeekendCheck_Changed;

            AddCustomHolidayButton.Click += AddCustomHolidayButton_Click;
            SaveOvertimeParamsButton.Click += SaveOvertimeParamsButton_Click;
            CancelOvertimeParamsButton.Click += CancelOvertimeParamsButton_Click;
        }

        private void RaccogliCheckboxFestivitaNazionali()
        {
            _checkFestivitaNazionali.Clear();

            foreach (var cb in FindVisualChildren<CheckBox>(MainTabs))
            {
                var content = cb.Content?.ToString()?.Trim();
                if (string.IsNullOrWhiteSpace(content)) continue;

                if (_festivitaNazionaliFisse.ContainsKey(content) || content == _checkPasqua || content == _checkPasquetta)
                {
                    _checkFestivitaNazionali.Add(cb);
                    cb.Checked += FestivitaNazionale_Changed;
                    cb.Unchecked += FestivitaNazionale_Changed;
                }
            }
        }

        private void RefreshParametriUIFromGlobal()
        {
            var p = App.ParametriGlobali ?? new ParametriStraordinari();

            // Slider: solo 0/15/30
            int soglia = SnapToAllowedBlockMinutes(p.SogliaMinutiStraordinario);
            if ((int)Math.Round(OvertimeSlider.Value) != soglia)
            {
                _isSnappingOvertimeSlider = true;
                OvertimeSlider.Value = soglia;
                _isSnappingOvertimeSlider = false;
            }

            OvertimeValue.Text = $"{soglia} minuti";

            // Weekend
            p.GiorniSempreFestivi ??= new List<DayOfWeek>();
            SaturdayCheck.IsChecked = p.GiorniSempreFestivi.Contains(DayOfWeek.Saturday);
            SundayCheck.IsChecked = p.GiorniSempreFestivi.Contains(DayOfWeek.Sunday);

            // Check festività nazionali (fisse + pasqua/pasquetta)
            p.FestivitaRicorrenti ??= new List<(int Mese, int Giorno)>();
            p.FestivitaAggiuntive ??= new List<DateTime>();
            int anno = DateTime.Now.Year;
            var pasqua = CalcolaPasqua(anno);
            var pasquetta = pasqua.AddDays(1);

            foreach (var cb in _checkFestivitaNazionali)
            {
                var content = cb.Content?.ToString()?.Trim() ?? string.Empty;

                if (_festivitaNazionaliFisse.TryGetValue(content, out var md))
                {
                    cb.IsChecked = p.FestivitaRicorrenti.Any(x => x.Mese == md.Mese && x.Giorno == md.Giorno);
                }
                else if (content == _checkPasqua)
                {
                    cb.IsChecked = p.FestivitaAggiuntive.Contains(pasqua.Date);
                }
                else if (content == _checkPasquetta)
                {
                    cb.IsChecked = p.FestivitaAggiuntive.Contains(pasquetta.Date);
                }
            }

            RefreshCustomHolidayList();
        }

        private void OvertimeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_isSnappingOvertimeSlider) return;

            _isSnappingOvertimeSlider = true;
            int snapped = SnapToAllowedBlockMinutes((int)Math.Round(OvertimeSlider.Value));
            if ((int)Math.Round(OvertimeSlider.Value) != snapped)
                OvertimeSlider.Value = snapped;
            _isSnappingOvertimeSlider = false;

            App.ParametriGlobali.SogliaMinutiStraordinario = snapped;
            OvertimeValue.Text = $"{snapped} minuti";

            // SALVATAGGIO IMMEDIATO
            App.SalvaParametriGlobali();
        }

        private void WeekendCheck_Changed(object sender, RoutedEventArgs e)
        {
            var p = App.ParametriGlobali;
            p.GiorniSempreFestivi ??= new List<DayOfWeek>();

            // Ricostruiamo solo sabato/domenica (non tocchiamo altri eventuali giorni)
            p.GiorniSempreFestivi.RemoveAll(d => d == DayOfWeek.Saturday || d == DayOfWeek.Sunday);
            if (SaturdayCheck.IsChecked == true) p.GiorniSempreFestivi.Add(DayOfWeek.Saturday);
            if (SundayCheck.IsChecked == true) p.GiorniSempreFestivi.Add(DayOfWeek.Sunday);

            App.SalvaParametriGlobali();
        }

        private void FestivitaNazionale_Changed(object sender, RoutedEventArgs e)
        {
            if (sender is not CheckBox cb) return;

            var p = App.ParametriGlobali;
            p.FestivitaRicorrenti ??= new List<(int Mese, int Giorno)>();
            p.FestivitaAggiuntive ??= new List<DateTime>();

            string content = cb.Content?.ToString()?.Trim() ?? string.Empty;

            if (_festivitaNazionaliFisse.TryGetValue(content, out var md))
            {
                // Feste ricorrenti fisse
                p.FestivitaRicorrenti.RemoveAll(x => x.Mese == md.Mese && x.Giorno == md.Giorno);
                if (cb.IsChecked == true)
                    p.FestivitaRicorrenti.Add(md);
            }
            else if (content == _checkPasqua || content == _checkPasquetta)
            {
                // Pasqua / Pasquetta: essendo mobili, li gestiamo come festività aggiuntive
                // (precompiliamo un piccolo range di anni per evitare "sparizioni" all'anno successivo).
                int startYear = DateTime.Now.Year - 1;
                int endYear = DateTime.Now.Year + 5;

                for (int year = startYear; year <= endYear; year++)
                {
                    var pasqua = CalcolaPasqua(year);
                    var target = content == _checkPasqua ? pasqua : pasqua.AddDays(1);
                    if (cb.IsChecked == true)
                    {
                        if (!p.FestivitaAggiuntive.Contains(target.Date))
                            p.FestivitaAggiuntive.Add(target.Date);
                    }
                    else
                    {
                        p.FestivitaAggiuntive.RemoveAll(d => d.Date == target.Date);
                    }
                }
            }

            App.SalvaParametriGlobali();
        }

        private void AddCustomHolidayButton_Click(object sender, RoutedEventArgs e)
        {
            if (CustomHolidayPicker.SelectedDate == null)
            {
                MessageBox.Show("Seleziona una data.");
                return;
            }

            var dt = CustomHolidayPicker.SelectedDate.Value.Date;
            var p = App.ParametriGlobali;
            p.FestivitaAggiuntive ??= new List<DateTime>();

            if (!p.FestivitaAggiuntive.Contains(dt))
                p.FestivitaAggiuntive.Add(dt);

            App.SalvaParametriGlobali();
            RefreshCustomHolidayList();
        }

        private void RefreshCustomHolidayList()
        {
            var p = App.ParametriGlobali;
            p.FestivitaAggiuntive ??= new List<DateTime>();

            CustomHolidayList.Items.Clear();

            foreach (var dt in p.FestivitaAggiuntive.Select(d => d.Date).Distinct().OrderBy(d => d))
            {
                var row = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin = new Thickness(0, 2, 0, 2)
                };

                row.Children.Add(new TextBlock
                {
                    Text = dt.ToString("dd/MM/yyyy"),
                    Foreground = Brushes.White,
                    VerticalAlignment = VerticalAlignment.Center,
                    Width = 120
                });

                var btn = new Button
                {
                    Content = "Rimuovi",
                    Width = 90,
                    Margin = new Thickness(8, 0, 0, 0),
                    Tag = dt,
                    Style = (Style)FindResource("GlassButton")
                };
                btn.Click += RemoveCustomHoliday_Click;
                row.Children.Add(btn);

                CustomHolidayList.Items.Add(row);
            }
        }

        private void RemoveCustomHoliday_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;
            if (btn.Tag is not DateTime dt) return;

            var p = App.ParametriGlobali;
            p.FestivitaAggiuntive ??= new List<DateTime>();
            p.FestivitaAggiuntive.RemoveAll(d => d.Date == dt.Date);
            App.SalvaParametriGlobali();
            RefreshCustomHolidayList();
        }

        private void SaveOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            // In realtà salviamo già "live" ad ogni modifica.
            App.SalvaParametriGlobali();
            MessageBox.Show("Parametri salvati.");
        }

        private void CancelOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            // Ricarica dal JSON e ripopola la UI
            App.CaricaParametriGlobali();
            RefreshParametriUIFromGlobal();
        }

        // =============================
        //  Helpers
        // =============================
        private static int SnapToAllowedBlockMinutes(int value)
        {
            // Valori ammessi: 0 / 15 / 30
            if (value <= 0) return 0;
            if (value <= 15) return 15;
            return 30;
        }

        // Algoritmo di Meeus/Jones/Butcher per la data di Pasqua (calendario gregoriano)
        private static DateTime CalcolaPasqua(int year)
        {
            int a = year % 19;
            int b = year / 100;
            int c = year % 100;
            int d = b / 4;
            int e = b % 4;
            int f = (b + 8) / 25;
            int g = (b - f + 1) / 3;
            int h = (19 * a + b - d - g + 15) % 30;
            int i = c / 4;
            int k = c % 4;
            int l = (32 + 2 * e + 2 * i - h - k) % 7;
            int m = (a + 11 * h + 22 * l) / 451;
            int month = (h + l - 7 * m + 114) / 31;
            int day = ((h + l - 7 * m + 114) % 31) + 1;
            return new DateTime(year, month, day);
        }

        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj == null) yield break;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                if (child is T t)
                    yield return t;

                foreach (T childOfChild in FindVisualChildren<T>(child))
                    yield return childOfChild;
            }
        }
    }
}
