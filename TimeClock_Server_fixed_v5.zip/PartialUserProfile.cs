// NOTE:
// In questo progetto `UserProfile` arriva da TimeClock.Core (assembly esterno).
// Non possiamo estenderlo con una `partial class` qui dentro, perché le partial
// devono stare nella *stessa* assembly della classe originale.
//
// In una versione precedente questo file dichiarava un altro
// `TimeClock.Core.Models.UserProfile` dentro TimeClock.Server causando conflitti
// di tipo (duplicate type) e decine di errori di compilazione.
//
// Per i campi extra (ore giornaliere previste, giorni lavorativi, ecc.) usiamo
// invece l'approccio "non invasivo" basato su extension methods:
//   - UserProfileExtras (ConditionalWeakTable + DTO Persisted per utenti.json)

namespace TimeClock.Server
{
    // Intenzionalmente vuoto.
}
