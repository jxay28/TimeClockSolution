using System;

namespace TimeClock.Core.Models
{
    /// <summary>
    /// Partial extension of UserProfile to include additional scheduling information.
    /// These properties are used to calculate daily working limits and weekly totals.
    /// </summary>
    public partial class UserProfile
    {
        /// <summary>
        /// Expected number of working hours per day.  Defaults to 8 if not specified.
        /// This value is used when determining how many hours are considered ordinary versus overtime on a given day.
        /// </summary>
        public double OreGiornalierePreviste { get; set; } = 8.0;

        /// <summary>
        /// Number of working days expected in a typical week (1–7).
        /// When combined with <see cref="OreGiornalierePreviste"/> this determines <see cref="OreContrattoSettimanali"/>.
        /// </summary>
        public int GiorniLavorativiSettimana { get; set; } = 5;
    }
}