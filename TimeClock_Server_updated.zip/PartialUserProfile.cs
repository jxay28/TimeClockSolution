namespace TimeClock.Server
{
    /// <summary>
    /// Questo file esiste solo per evitare conflitti:
    /// non deve MAI definire un tipo "UserProfile" qui dentro,
    /// perché l'applicazione usa quello di TimeClock.Core.
    ///
    /// I campi extra (ore giornaliere previste, giorni lavorativi, ecc.)
    /// sono gestiti tramite <see cref="UserProfileExtras"/> e persistiti
    /// su JSON.
    /// </summary>
    internal static class PartialUserProfile
    {
    }
}
