using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using Microsoft.Win32;

using TimeClock.Core.Models;
using TimeClock.Core.Services;

namespace TimeClock.Server
{
    public partial class MainWindow : Window
    {
        private string _csvFolder = string.Empty;
        private List<UserProfile> _users = new();

        // Flag anti-ricorsione quando "snappiamo" lo slider
        private bool _isSnappingOvertimeSlider;

        private static readonly JsonSerializerOptions JsonOpts = new()
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        public MainWindow()
        {
            InitializeComponent();

            WireParametriStraordinariUi();

            // Carico cartella CSV salvata
            _csvFolder = Properties.Settings.Default.CsvFolderPath;
            if (!string.IsNullOrWhiteSpace(_csvFolder) && Directory.Exists(_csvFolder))
            {
                CsvPathBox.Text = _csvFolder;
                LoadUsers();
            }
            else
            {
                CsvPathBox.Text = "Nessuna cartella selezionata";
                _csvFolder = string.Empty;
            }

            // Parametri straordinari sempre dalla fonte globale JSON
            LoadParametriStraordinariIntoUi();

            // Festività custom (tab festività) mostra la stessa fonte di verità
            LoadCustomHolidaysGrid();
        }

        // ===========================
        //   UI GENERALI (menu)
        // ===========================
        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            // Se hai un menu laterale, qui puoi gestire l'apertura/chiusura.
        }

        private void Min_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // ===========================
        //   CARTELLA CSV
        // ===========================
        private void SelectCsvFolder_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Seleziona la cartella dove salvare/leggere i CSV".
            };

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                _csvFolder = dlg.SelectedPath;
                CsvPathBox.Text = _csvFolder;
                Properties.Settings.Default.CsvFolderPath = _csvFolder;
                Properties.Settings.Default.Save();

                LoadUsers();
                LoadCustomHolidaysGrid();
            }
        }

        // ===========================
        //   UTENTI
        // ===========================
        private void LoadUsers()
        {
            _users = new List<UserProfile>();
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                UserGrid.ItemsSource = _users;
                return;
            }

            string filePath = Path.Combine(_csvFolder, "utenti.json");
            if (!File.Exists(filePath))
            {
                UserGrid.ItemsSource = _users;
                return;
            }

            try
            {
                var json = File.ReadAllText(filePath);
                // Nuova persistenza: DTO Persisted (include campi extra)
                var persisted = JsonSerializer.Deserialize<List<UserProfileExtras.Persisted>>(json, JsonOpts)
                                ?? new List<UserProfileExtras.Persisted>();

                foreach (var p in persisted)
                {
                    var u = new UserProfile
                    {
                        Id = string.IsNullOrWhiteSpace(p.Id) ? Guid.NewGuid().ToString() : p.Id,
                        SequenceNumber = p.SequenceNumber,
                        Nome = p.Nome,
                        Cognome = p.Cognome,
                        Ruolo = p.Ruolo,
                        DataAssunzione = p.DataAssunzione,
                        OreContrattoSettimanali = p.OreContrattoSettimanali,
                        CompensoOrarioBase = p.CompensoOrarioBase,
                        CompensoOrarioExtra = p.CompensoOrarioExtra,
                        OrarioIngresso1 = p.OrarioIngresso1,
                        OrarioUscita1 = p.OrarioUscita1,
                        OrarioIngresso2 = p.OrarioIngresso2,
                        OrarioUscita2 = p.OrarioUscita2
                    };

                    // Campi extra (non presenti nella classe Core)
                    u.SetOreGiornalierePreviste(p.OreGiornalierePreviste);
                    u.SetGiorniLavorativiSettimana(p.GiorniLavorativiSettimana);

                    _users.Add(u);
                }
            }
            catch
            {
                // Se il file è nel vecchio formato (List<UserProfile>), proviamo fallback.
                try
                {
                    var legacy = JsonSerializer.Deserialize<List<UserProfile>>(File.ReadAllText(filePath), JsonOpts)
                                 ?? new List<UserProfile>();
                    _users = legacy;

                    // Migrazione "soft": se arriviamo dal vecchio JSON (senza campi extra),
                    // inizializziamo dei default sensati.
                    foreach (var u in _users)
                    {
                        // Default: 5 giorni e ore giornaliere derivate dalle ore settimanali.
                        int giorni = 5;
                        u.SetGiorniLavorativiSettimana(giorni);
                        double oreDay = (u.OreContrattoSettimanali > 0 && giorni > 0)
                            ? u.OreContrattoSettimanali / giorni
                            : 8.0;
                        u.SetOreGiornalierePreviste(oreDay);
                    }
                }
                catch
                {
                    _users = new List<UserProfile>();
                }
            }

            UserGrid.ItemsSource = null;
            UserGrid.ItemsSource = _users;
        }

        private void SaveUsers()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder)) return;

            string filePath = Path.Combine(_csvFolder, "utenti.json");

            var persisted = _users.Select(u => new UserProfileExtras.Persisted
            {
                Id = u.Id,
                SequenceNumber = u.SequenceNumber,
                Nome = u.Nome,
                Cognome = u.Cognome,
                Ruolo = u.Ruolo,
                DataAssunzione = u.DataAssunzione,
                OreContrattoSettimanali = u.OreContrattoSettimanali,
                CompensoOrarioBase = u.CompensoOrarioBase,
                CompensoOrarioExtra = u.CompensoOrarioExtra,
                OrarioIngresso1 = u.OrarioIngresso1,
                OrarioUscita1 = u.OrarioUscita1,
                OrarioIngresso2 = u.OrarioIngresso2,
                OrarioUscita2 = u.OrarioUscita2,
                OreGiornalierePreviste = u.GetOreGiornalierePreviste(0),
                GiorniLavorativiSettimana = u.GetGiorniLavorativiSettimana(0)
            }).ToList();

            File.WriteAllText(filePath, JsonSerializer.Serialize(persisted, JsonOpts));

            // Legacy export CSV utenti (non più fonte di verità)
            try
            {
                var csvLines = new List<string> { "Id,SequenceNumber,Nome,Cognome,Ruolo,DataAssunzione,OreContrattoSettimanali,CompensoOrarioBase,CompensoOrarioExtra,OrarioIngresso1,OrarioUscita1,OrarioIngresso2,OrarioUscita2,OreGiornalierePreviste,GiorniLavorativiSettimana" };
                foreach (var u in _users)
                {
                    csvLines.Add(string.Join(",", new[]
                    {
                        u.Id,
                        u.SequenceNumber.ToString(),
                        EscapeCsv(u.Nome),
                        EscapeCsv(u.Cognome),
                        EscapeCsv(u.Ruolo),
                        u.DataAssunzione.ToString("yyyy-MM-dd"),
                        u.OreContrattoSettimanali.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        u.CompensoOrarioBase.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        u.CompensoOrarioExtra.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        u.OrarioIngresso1 ?? "",
                        u.OrarioUscita1 ?? "",
                        u.OrarioIngresso2 ?? "",
                        u.OrarioUscita2 ?? "",
                        u.GetOreGiornalierePreviste(0).ToString(System.Globalization.CultureInfo.InvariantCulture),
                        u.GetGiorniLavorativiSettimana(0).ToString()
                    }));
                }
                File.WriteAllLines(Path.Combine(_csvFolder, "utenti.csv"), csvLines);
            }
            catch
            {
                // Non blocchiamo l'app se l'export legacy fallisce.
            }
        }

        private static string EscapeCsv(string? s)
        {
            s ??= string.Empty;
            if (s.Contains(',') || s.Contains('"') || s.Contains('\n'))
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.");
                return;
            }

            var win = new AddUserWindow(_csvFolder);
            if (win.ShowDialog() == true && win.CreatedUser != null)
            {
                _users.Add(win.CreatedUser);
                _users = _users.OrderBy(u => u.SequenceNumber).ToList();
                SaveUsers();
                UserGrid.ItemsSource = null;
                UserGrid.ItemsSource = _users;
            }
        }

        // ===========================
        //   REPORT
        // ===========================
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.");
                return;
            }

            var win = new ReportWindow(_csvFolder, _users);
            win.Owner = this;
            win.ShowDialog();
        }

        // ===========================
        //   FESTIVITÀ (TAB LEGACY / VISTA)
        //   Ora usa ParametriGlobali.FestivitaAggiuntive
        // ===========================
        private void LoadCustomHolidaysGrid()
        {
            if (HolidayGrid == null) return;

            var dates = App.ParametriGlobali?.FestivitaAggiuntive?.OrderBy(d => d).ToList()
                        ?? new List<DateTime>();

            // Holiday arriva da TimeClock.Core.Models; se non ha Descrizione, la colonna verrà ignorata.
            var list = dates.Select(d => new Holiday { Data = d.Date, Descrizione = string.Empty }).ToList();
            HolidayGrid.ItemsSource = null;
            HolidayGrid.ItemsSource = list;
        }

        private void AddHoliday_Click(object sender, RoutedEventArgs e)
        {
            // Manteniamo questo pulsante (design invariato) ma ora scrive su JSON.
            // Usiamo due input per compatibilità: data obbligatoria, descrizione ignorata.
            string dataStr = Microsoft.VisualBasic.Interaction.InputBox(
                "Inserisci la data (es. 25/12/2025):",
                "Nuova festività",
                DateTime.Now.ToString("dd/MM/yyyy"));

            if (!DateTime.TryParse(dataStr, out var date))
            {
                MessageBox.Show("Data non valida.");
                return;
            }

            // Descrizione legacy (non persistiamo, ma la chiediamo per UI)
            _ = Microsoft.VisualBasic.Interaction.InputBox(
                "Descrizione (opzionale):",
                "Nuova festività",
                "");

            App.ParametriGlobali ??= new ParametriStraordinari();
            App.ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();

            var d = date.Date;
            if (!App.ParametriGlobali.FestivitaAggiuntive.Contains(d))
            {
                App.ParametriGlobali.FestivitaAggiuntive.Add(d);
                App.ParametriGlobali.FestivitaAggiuntive = App.ParametriGlobali.FestivitaAggiuntive.OrderBy(x => x).ToList();
                App.SalvaParametriGlobali();
            }

            LoadCustomHolidaysGrid();
            RefreshCustomHolidayList();
        }

        // ===========================
        //   PARAMETRI STRAORDINARI (GLOBALI)
        // ===========================
        private void WireParametriStraordinariUi()
        {
            // Slider (dimensione blocco): 0 / 15 / 30
            if (FindName("OvertimeSlider") is Slider slider)
            {
                slider.Minimum = 0;
                slider.Maximum = 30;
                slider.TickFrequency = 15;
                slider.IsSnapToTickEnabled = true;
                slider.ValueChanged += OvertimeSlider_ValueChanged;
            }

            // Weekend
            if (FindName("SaturdayCheck") is CheckBox sat)
            {
                sat.Checked += WeekendCheck_Changed;
                sat.Unchecked += WeekendCheck_Changed;
            }
            if (FindName("SundayCheck") is CheckBox sun)
            {
                sun.Checked += WeekendCheck_Changed;
                sun.Unchecked += WeekendCheck_Changed;
            }

            // Festività personalizzate (date picker)
            if (FindName("AddCustomHolidayButton") is Button addBtn)
                addBtn.Click += AddCustomHolidayButton_Click;

            if (FindName("SaveOvertimeParamsButton") is Button saveBtn)
                saveBtn.Click += SaveOvertimeParamsButton_Click;

            if (FindName("CancelOvertimeParamsButton") is Button cancelBtn)
                cancelBtn.Click += CancelOvertimeParamsButton_Click;
        }

        private void LoadParametriStraordinariIntoUi()
        {
            App.ParametriGlobali ??= new ParametriStraordinari();
            var p = App.ParametriGlobali;

            // Slider
            if (FindName("OvertimeSlider") is Slider slider)
            {
                _isSnappingOvertimeSlider = true;
                int snapped = SnapOvertimeMinutes(p.SogliaMinutiStraordinario);
                slider.Value = snapped;
                p.SogliaMinutiStraordinario = snapped;
                _isSnappingOvertimeSlider = false;
            }

            UpdateOvertimeLabel();

            // Weekend
            if (FindName("SaturdayCheck") is CheckBox sat)
                sat.IsChecked = p.GiorniSempreFestivi?.Contains(DayOfWeek.Saturday) == true;
            if (FindName("SundayCheck") is CheckBox sun)
                sun.IsChecked = p.GiorniSempreFestivi?.Contains(DayOfWeek.Sunday) == true;

            RefreshCustomHolidayList();
        }

        private static int SnapOvertimeMinutes(int raw)
        {
            // Valori ammessi: 0 / 15 / 30
            if (raw <= 0) return 0;
            if (raw <= 15) return 15;
            return 30;
        }

        private void UpdateOvertimeLabel()
        {
            if (FindName("OvertimeValue") is TextBlock lbl)
            {
                int v = App.ParametriGlobali?.SogliaMinutiStraordinario ?? 0;
                lbl.Text = $"{v} minuti";
            }
        }

        private void OvertimeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_isSnappingOvertimeSlider) return;
            if (sender is not Slider slider) return;

            int snapped = SnapOvertimeMinutes((int)Math.Round(e.NewValue));

            // Riporta lo slider su un valore valido (evita che resti su 7, 22, ecc.)
            if ((int)Math.Round(slider.Value) != snapped)
            {
                _isSnappingOvertimeSlider = true;
                slider.Value = snapped;
                _isSnappingOvertimeSlider = false;
            }

            App.ParametriGlobali ??= new ParametriStraordinari();
            App.ParametriGlobali.SogliaMinutiStraordinario = snapped;
            App.SalvaParametriGlobali();

            UpdateOvertimeLabel();
        }

        private void WeekendCheck_Changed(object sender, RoutedEventArgs e)
        {
            App.ParametriGlobali ??= new ParametriStraordinari();
            var p = App.ParametriGlobali;
            p.GiorniSempreFestivi ??= new List<DayOfWeek>();
            p.GiorniSempreFestivi.Clear();

            if ((FindName("SaturdayCheck") as CheckBox)?.IsChecked == true)
                p.GiorniSempreFestivi.Add(DayOfWeek.Saturday);
            if ((FindName("SundayCheck") as CheckBox)?.IsChecked == true)
                p.GiorniSempreFestivi.Add(DayOfWeek.Sunday);

            App.SalvaParametriGlobali();
        }

        private void AddCustomHolidayButton_Click(object sender, RoutedEventArgs e)
        {
            if (FindName("CustomHolidayPicker") is not DatePicker picker || picker.SelectedDate == null)
            {
                MessageBox.Show("Seleziona una data.");
                return;
            }

            var date = picker.SelectedDate.Value.Date;
            App.ParametriGlobali ??= new ParametriStraordinari();
            var p = App.ParametriGlobali;
            p.FestivitaAggiuntive ??= new List<DateTime>();

            if (!p.FestivitaAggiuntive.Contains(date))
            {
                p.FestivitaAggiuntive.Add(date);
                p.FestivitaAggiuntive = p.FestivitaAggiuntive.OrderBy(d => d).ToList();
                App.SalvaParametriGlobali();
            }

            picker.SelectedDate = null;
            RefreshCustomHolidayList();
            LoadCustomHolidaysGrid();
        }

        private void RemoveCustomHolidayButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not DateTime d) return;
            var p = App.ParametriGlobali;
            if (p?.FestivitaAggiuntive == null) return;

            p.FestivitaAggiuntive.RemoveAll(x => x.Date == d.Date);
            App.SalvaParametriGlobali();

            RefreshCustomHolidayList();
            LoadCustomHolidaysGrid();
        }

        private void RefreshCustomHolidayList()
        {
            if (FindName("CustomHolidayList") is not ItemsControl list) return;

            var dates = App.ParametriGlobali?.FestivitaAggiuntive?.OrderBy(d => d).ToList()
                        ?? new List<DateTime>();

            var items = new List<FrameworkElement>();
            foreach (var d in dates)
            {
                var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
                panel.Children.Add(new TextBlock
                {
                    Text = d.ToString("dd/MM/yyyy"),
                    Foreground = Brushes.White,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 10, 0)
                });

                var btn = new Button
                {
                    Content = "Rimuovi",
                    Tag = d,
                    Padding = new Thickness(8, 2, 8, 2),
                    Margin = new Thickness(4, 0, 0, 0)
                };
                btn.Click += RemoveCustomHolidayButton_Click;
                panel.Children.Add(btn);
                items.Add(panel);
            }

            list.ItemsSource = items;
        }

        private void SaveOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            // Ormai salviamo già subito, ma manteniamo il pulsante.
            App.SalvaParametriGlobali();
            MessageBox.Show("Parametri salvati.");
        }

        private void CancelOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            // Ricarica dal file JSON su disco.
            try
            {
                string file = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "parametri_straordinari.json");
                if (File.Exists(file))
                {
                    var read = JsonSerializer.Deserialize<ParametriStraordinari>(File.ReadAllText(file), JsonOpts);
                    if (read != null)
                        App.ParametriGlobali = read;
                }
            }
            catch
            {
                // Ignora
            }

            LoadParametriStraordinariIntoUi();
            LoadCustomHolidaysGrid();
        }
    }
}
