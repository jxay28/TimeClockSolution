using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class AddUserWindow : Window
    {
        private readonly string _csvFolder;

        public UserProfile CreatedUser { get; private set; }

        public AddUserWindow(string csvFolder)
        {
            InitializeComponent();
            _csvFolder = csvFolder;

            // Default UI
            if (FindName("GiorniLavorativiCombo") is ComboBox gg)
                gg.SelectedIndex = 4; // 5 giorni

            // Default orari (legacy)
            Ingresso1Combo.SelectedIndex = 4; // 08:00
            Uscita1Combo.SelectedIndex = 0;   // 12:00
            Ingresso2Combo.SelectedIndex = 2; // 13:00
            Uscita2Combo.SelectedIndex = 2;   // 17:00

            // Auto-calc ore settimanali
            OreGiornoBox.TextChanged += (_, __) => RecalcOreSettimanali();
            GiorniLavorativiCombo.SelectionChanged += (_, __) => RecalcOreSettimanali();
            RecalcOreSettimanali();

            LoadSequentialNumber();
        }

        private void LoadSequentialNumber()
        {
            try
            {
                string filePath = Path.Combine(_csvFolder, "utenti.json");
                int next = 1;

                if (File.Exists(filePath))
                {
                    string json = File.ReadAllText(filePath);

                    // Nuovo formato (Persisted)
                    try
                    {
                        var list = JsonSerializer.Deserialize<List<UserProfileExtras.Persisted>>(json);
                        if (list != null && list.Count > 0)
                            next = list.Max(u => u.SequenceNumber) + 1;
                    }
                    catch
                    {
                        // Legacy: file salvato come List<UserProfile>
                        try
                        {
                            var legacy = JsonSerializer.Deserialize<List<UserProfile>>(json);
                            if (legacy != null && legacy.Count > 0)
                                next = legacy.Max(u => u.SequenceNumber) + 1;
                        }
                        catch
                        {
                            // ignora: fallback resta 1
                        }
                    }
                }

                SeqNumberBox.Text = next.ToString(CultureInfo.InvariantCulture);
            }
            catch
            {
                SeqNumberBox.Text = "1";
            }
        }

        private void RecalcOreSettimanali()
        {
            if (OreBox == null) return;

            double oreGiorno = ParseDouble(OreGiornoBox.Text, 8.0);
            int giorni = ParseIntFromCombo(GiorniLavorativiCombo, 5);
            double oreSett = Math.Round(oreGiorno * giorni, 2);

            OreBox.Text = oreSett.ToString("0.##", CultureInfo.CurrentCulture);
        }

        private static double ParseDouble(string? text, double fallback)
        {
            if (string.IsNullOrWhiteSpace(text)) return fallback;

            // accetta sia "," che "." indipendentemente dalla cultura
            var t = text.Trim().Replace(',', '.');
            if (double.TryParse(t, NumberStyles.Float, CultureInfo.InvariantCulture, out double d))
                return d;
            return fallback;
        }

        private static int ParseIntFromCombo(ComboBox combo, int fallback)
        {
            if (combo?.SelectedItem is ComboBoxItem item && int.TryParse(item.Content?.ToString(), out int v))
                return v;
            return fallback;
        }

        private static TimeSpan? GetTimeFromCombo(ComboBox combo)
        {
            if (combo?.SelectedItem is ComboBoxItem item && TimeSpan.TryParse(item.Content?.ToString(), out var ts))
                return ts;
            return null;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            string nome = NomeBox.Text.Trim();
            string cognome = CognomeBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(cognome))
            {
                MessageBox.Show("Inserisci Nome e Cognome.");
                return;
            }

            // Nuovi parametri contrattuali
            double oreGiorno = ParseDouble(OreGiornoBox.Text, 8.0);
            int giorniLav = ParseIntFromCombo(GiorniLavorativiCombo, 5);
            double oreSett = Math.Round(oreGiorno * giorniLav, 2);

            // Compensi
            double basePay = ParseDouble(SalarioBaseBox.Text, 0);
            double extraPay = ParseDouble(SalarioExtraBox.Text, 0);

            // Orari previsti (legacy): li manteniamo in anagrafica ma NON sono più usati per "decidere" lo straordinario.
            TimeSpan? in1 = GetTimeFromCombo(Ingresso1Combo);
            TimeSpan? out1 = GetTimeFromCombo(Uscita1Combo);
            TimeSpan? in2 = GetTimeFromCombo(Ingresso2Combo);
            TimeSpan? out2 = GetTimeFromCombo(Uscita2Combo);

            if (!int.TryParse(SeqNumberBox.Text, out int seq))
                seq = 1;

            var user = new UserProfile
            {
                Id = Guid.NewGuid().ToString(),
                SequenceNumber = seq,
                Nome = nome,
                Cognome = cognome,
                Ruolo = RuoloBox.Text.Trim(),
                DataAssunzione = AssunzionePicker.SelectedDate ?? DateTime.Now,
                OreContrattoSettimanali = oreSett,
                CompensoOrarioBase = basePay,
                CompensoOrarioExtra = extraPay,
                OrarioIngresso1 = in1,
                OrarioUscita1 = out1,
                OrarioIngresso2 = in2,
                OrarioUscita2 = out2
            };

            // Persistiamo i nuovi campi via extras.
            user.SetOreGiornalierePreviste(oreGiorno);
            user.SetGiorniLavorativiSettimana(giorniLav);

            CreatedUser = user;
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
