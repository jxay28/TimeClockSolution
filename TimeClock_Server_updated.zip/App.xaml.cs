using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class App : Application
    {
        public static ParametriStraordinari ParametriGlobali;

        // Percorso stabile: sempre nella cartella dell'eseguibile.
        // Evita bug dovuti al working directory (VS, collegamenti, ecc.).
        private static string ParametriPath => Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory,
            "parametri_straordinari.json");

        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            if (File.Exists(ParametriPath))
            {
                try
                {
                    ParametriGlobali = JsonSerializer.Deserialize<ParametriStraordinari>(
                        File.ReadAllText(ParametriPath),
                        JsonOptions) ?? new ParametriStraordinari();
                }
                catch
                {
                    // Se il JSON è corrotto/non compatibile, ripartiamo da default.
                    ParametriGlobali = new ParametriStraordinari();
                }
            }
            else
            {
                ParametriGlobali = new ParametriStraordinari();
                File.WriteAllText(ParametriPath,
                    JsonSerializer.Serialize(ParametriGlobali, JsonOptions));
            }
        }

        public static void SalvaParametriGlobali()
        {
            if (ParametriGlobali == null)
                ParametriGlobali = new ParametriStraordinari();

            File.WriteAllText(ParametriPath,
                JsonSerializer.Serialize(ParametriGlobali, JsonOptions));
        }
    }
}
