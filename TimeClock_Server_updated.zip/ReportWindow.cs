using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public class TimeCardEntry
    {
        public DateTime Ingresso { get; set; }
        public DateTime Uscita { get; set; }
        public TimeSpan Durata => Uscita - Ingresso;
    }

    public class WorkPair
    {
        public DateTime Start { get; set; }
        public DateTime End { get; set; }

        public WorkPair(DateTime start, DateTime end)
        {
            Start = start;
            End = end;
        }
    }

    /// <summary>
    /// Una riga del report (può contenere fino a 2 coppie ingresso/uscita).
    /// NOTE: Durata1/2 sono *durate riconosciute* dopo l'arrotondamento a blocchi.
    /// </summary>
    public class ReportRow
    {
        public int Giorno { get; set; }

        public string Entrata1 { get; set; } = "";
        public string Uscita1 { get; set; } = "";
        public string Durata1Visual { get; set; } = "";

        public string Entrata2 { get; set; } = "";
        public string Uscita2 { get; set; } = "";
        public string Durata2Visual { get; set; } = "";

        public bool IsFestivo { get; set; }

        // Per evitare problemi di floating-point, la "verità" è in minuti.
        public int MinutiOrdinarie { get; set; }
        public int MinutiStraordinarie { get; set; }

        public double OreOrdinarie => MinutiOrdinarie / 60.0;
        public double OreStraordinarie => MinutiStraordinarie / 60.0;

        public string OreOrdinarieVisual => FormatMinutes(MinutiOrdinarie);
        public string OreStraordinarieVisual => FormatMinutes(MinutiStraordinarie);

        public string Note { get; set; } = "";

        public static string FormatMinutes(int minutes)
        {
            if (minutes <= 0) return "00:00";
            int h = minutes / 60;
            int m = minutes % 60;
            return $"{h:00}:{m:00}";
        }
    }

    public partial class ReportWindow : Window
    {
        private readonly string _csvFolder;
        private readonly List<UserProfile> _users;

        private int _selectedYear;
        private int _selectedMonth;
        private UserProfile? _selectedUser;

        public ReportWindow(List<UserProfile> users, string csvFolder)
        {
            InitializeComponent();
            _users = users;
            _csvFolder = csvFolder;

            // Popola user combo
            UserComboBox.ItemsSource = _users;
            UserComboBox.DisplayMemberPath = "Nome";
            UserComboBox.SelectedIndex = _users.Any() ? 0 : -1;

            // Popola mesi/anni
            MonthComboBox.ItemsSource = Enumerable.Range(1, 12).ToList();
            MonthComboBox.SelectedIndex = DateTime.Now.Month - 1;

            YearComboBox.ItemsSource = Enumerable.Range(DateTime.Now.Year - 5, 11).ToList();
            YearComboBox.SelectedItem = DateTime.Now.Year;

            // Aggiorna selezioni
            _selectedYear = (int)YearComboBox.SelectedItem;
            _selectedMonth = (int)MonthComboBox.SelectedItem;
            _selectedUser = UserComboBox.SelectedItem as UserProfile;

            // Recalc quando edit
            ReportGrid.CellEditEnding += ReportGrid_CellEditEnding;
        }

        private void CaricaReport_Click(object sender, RoutedEventArgs e)
        {
            if (UserComboBox.SelectedItem is not UserProfile user)
            {
                MessageBox.Show("Seleziona un utente.");
                return;
            }

            _selectedUser = user;
            _selectedYear = (int)(YearComboBox.SelectedItem ?? DateTime.Now.Year);
            _selectedMonth = (int)(MonthComboBox.SelectedItem ?? DateTime.Now.Month);

            // Leggi timbrature da CSV
            string filePath = Path.Combine(_csvFolder, $"{user.Id}.csv");
            var entries = new List<TimeCardEntry>();
            if (File.Exists(filePath))
            {
                foreach (var line in File.ReadAllLines(filePath).Skip(1))
                {
                    var parts = line.Split(';');
                    if (parts.Length < 3) continue;
                    if (!DateTime.TryParse(parts[0], out DateTime giorno)) continue;
                    if (!TimeSpan.TryParse(parts[1], out var inTime)) continue;
                    if (!TimeSpan.TryParse(parts[2], out var outTime)) continue;

                    DateTime ingresso = giorno.Date.Add(inTime);
                    DateTime uscita = giorno.Date.Add(outTime);
                    if (uscita <= ingresso)
                        uscita = uscita.AddDays(1);

                    entries.Add(new TimeCardEntry
                    {
                        Ingresso = ingresso,
                        Uscita = uscita
                    });
                }
            }

            // Filtra mese + buffer (2 giorni prima e dopo)
            var startDate = new DateTime(_selectedYear, _selectedMonth, 1).AddDays(-2);
            var endDate = new DateTime(_selectedYear, _selectedMonth, DateTime.DaysInMonth(_selectedYear, _selectedMonth)).AddDays(2);
            var monthEntries = entries
                .Where(e => e.Ingresso.Date >= startDate && e.Ingresso.Date <= endDate)
                .OrderBy(e => e.Ingresso)
                .ToList();

            // Coppie globali
            var coppie = CostruisciCoppieGlobali(monthEntries);

            // Costruisci righe 1..giorni mese
            var righeReport = new List<ReportRow>();
            int giorniNelMese = DateTime.DaysInMonth(_selectedYear, _selectedMonth);

            for (int d = 1; d <= giorniNelMese; d++)
            {
                var date = new DateTime(_selectedYear, _selectedMonth, d);
                var coppieGiorno = coppie
                    .Where(c => c.Start.Year == _selectedYear && c.Start.Month == _selectedMonth && c.Start.Day == d)
                    .OrderBy(c => c.Start)
                    .ToList();

                var dayRows = new List<ReportRow>();

                if (coppieGiorno.Count == 0)
                {
                    dayRows.Add(new ReportRow { Giorno = d });
                }
                else
                {
                    int i = 0;
                    while (i < coppieGiorno.Count)
                    {
                        var row = new ReportRow { Giorno = d };

                        var c1 = coppieGiorno[i];
                        row.Entrata1 = c1.Start.ToString("HH:mm");
                        row.Uscita1 = c1.End.ToString("HH:mm");
                        i++;

                        if (i < coppieGiorno.Count)
                        {
                            var c2 = coppieGiorno[i];
                            row.Entrata2 = c2.Start.ToString("HH:mm");
                            row.Uscita2 = c2.End.ToString("HH:mm");
                            i++;
                        }

                        dayRows.Add(row);
                    }
                }

                // Calcolo (per-giorno, cap ore ordinarie condiviso)
                RecalculateDayRows(dayRows, date, user);

                righeReport.AddRange(dayRows);
            }

            ReportGrid.ItemsSource = righeReport;
            AggiornaTotali();
        }

        private void ReportGrid_CellEditEnding(object? sender, DataGridCellEditEndingEventArgs e)
        {
            // Aspetta che la cella committi davvero, poi ricalcola tutto il giorno.
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (e.Row?.Item is not ReportRow edited) return;

                // (Particolarmente importante per DataGridCheckBoxColumn)
                ReportGrid.CommitEdit(DataGridEditingUnit.Cell, true);
                ReportGrid.CommitEdit(DataGridEditingUnit.Row, true);
                RecalculateDayInGrid(edited.Giorno);
            }), DispatcherPriority.Background);
        }

        private void RecalculateDayInGrid(int day)
        {
            if (_selectedUser == null) return;
            if (ReportGrid.ItemsSource is not List<ReportRow> allRows) return;

            var date = new DateTime(_selectedYear, _selectedMonth, day);
            var dayRows = allRows.Where(r => r.Giorno == day).ToList();
            if (dayRows.Count == 0) return;

            RecalculateDayRows(dayRows, date, _selectedUser);

            // Refresh UI
            ReportGrid.Items.Refresh();
            AggiornaTotali();
        }

        /// <summary>
        /// CORE: calcola Durate riconosciute + Ordinarie/Straordinarie per TUTTE le righe di un giorno.
        /// </summary>
        private void RecalculateDayRows(List<ReportRow> dayRows, DateTime dayDate, UserProfile user)
        {
            int blockMinutes = GetBlockMinutes(); // 0/15/30
            int expectedDailyMinutes = GetExpectedDailyMinutes(user);

            bool autoHoliday = IsGiornoFestivo(dayDate);
            bool manualHoliday = dayRows.Any(r => r.IsFestivo);
            bool festivo = autoHoliday || manualHoliday;

            // Festivo vale per tutto il giorno: uniformiamo il checkbox su tutte le righe.
            foreach (var r in dayRows)
                r.IsFestivo = festivo;

            // Reset output
            foreach (var r in dayRows)
            {
                r.Durata1Visual = "";
                r.Durata2Visual = "";
                r.MinutiOrdinarie = 0;
                r.MinutiStraordinarie = 0;
            }

            // Raccogliamo tutti gli slot (coppie) validi del giorno, con riferimento a riga+slot
            var slots = new List<(ReportRow row, int slotIndex, DateTime start, DateTime end, int recognizedMinutes)>();

            foreach (var r in dayRows)
            {
                if (TryParsePair(dayDate, r.Entrata1, r.Uscita1, out DateTime s1, out DateTime e1))
                {
                    int rec = ComputeRecognizedMinutes(s1, e1, blockMinutes);
                    slots.Add((r, 1, s1, e1, rec));
                    r.Durata1Visual = ReportRow.FormatMinutes(rec);
                }

                if (TryParsePair(dayDate, r.Entrata2, r.Uscita2, out DateTime s2, out DateTime e2))
                {
                    int rec = ComputeRecognizedMinutes(s2, e2, blockMinutes);
                    slots.Add((r, 2, s2, e2, rec));
                    r.Durata2Visual = ReportRow.FormatMinutes(rec);
                }
            }

            // Ordina cronologicamente (per distribuire l'ordinario prima e lo straordinario dopo)
            slots = slots.OrderBy(s => s.start).ToList();

            int remainingOrd = festivo ? 0 : Math.Max(0, expectedDailyMinutes);

            foreach (var slot in slots)
            {
                int rec = Math.Max(0, slot.recognizedMinutes);

                int ord = 0;
                int extra = 0;

                if (festivo)
                {
                    extra = rec;
                }
                else
                {
                    ord = Math.Min(rec, remainingOrd);
                    extra = rec - ord;
                    remainingOrd -= ord;
                }

                slot.row.MinutiOrdinarie += ord;
                slot.row.MinutiStraordinarie += extra;
            }
        }

        private static int GetBlockMinutes()
        {
            int raw = App.ParametriGlobali?.SogliaMinutiStraordinario ?? 0;
            // Valori ammessi: 0 / 15 / 30
            if (raw <= 0) return 0;
            if (raw <= 15) return 15;
            return 30;
        }

        private static int GetExpectedDailyMinutes(UserProfile user)
        {
            int giorni = user.GetGiorniLavorativiSettimana(5);
            giorni = Math.Clamp(giorni, 1, 7);

            double fallbackOreGiorno = (user.OreContrattoSettimanali > 0)
                ? (user.OreContrattoSettimanali / giorni)
                : 8.0;

            double oreGiorno = user.GetOreGiornalierePreviste(fallbackOreGiorno);
            if (oreGiorno < 0) oreGiorno = 0;

            // Lavoriamo in minuti interi.
            return (int)Math.Round(oreGiorno * 60.0);
        }

        private static bool TryParsePair(DateTime dayDate, string? startStr, string? endStr, out DateTime start, out DateTime end)
        {
            start = default;
            end = default;

            if (string.IsNullOrWhiteSpace(startStr) || string.IsNullOrWhiteSpace(endStr))
                return false;

            if (!TimeSpan.TryParse(startStr.Trim(), out var sTime))
                return false;
            if (!TimeSpan.TryParse(endStr.Trim(), out var eTime))
                return false;

            start = dayDate.Date.Add(sTime);
            end = dayDate.Date.Add(eTime);
            if (end <= start)
                end = end.AddDays(1);

            return true;
        }

        private static int ComputeRecognizedMinutes(DateTime start, DateTime end, int blockMinutes)
        {
            if (end <= start) return 0;

            if (blockMinutes <= 0)
            {
                return (int)Math.Round((end - start).TotalMinutes);
            }

            DateTime startAligned = RoundUpToBlock(start, blockMinutes);
            DateTime endAligned = RoundDownToBlock(end, blockMinutes);

            if (endAligned <= startAligned) return 0;

            return (int)Math.Round((endAligned - startAligned).TotalMinutes);
        }

        private static DateTime RoundUpToBlock(DateTime dt, int blockMinutes)
        {
            if (blockMinutes <= 0) return dt;
            var baseDay = dt.Date;
            double minutes = (dt - baseDay).TotalMinutes;
            double rounded = Math.Ceiling(minutes / blockMinutes) * blockMinutes;
            return baseDay.AddMinutes(rounded);
        }

        private static DateTime RoundDownToBlock(DateTime dt, int blockMinutes)
        {
            if (blockMinutes <= 0) return dt;
            var baseDay = dt.Date;
            double minutes = (dt - baseDay).TotalMinutes;
            double rounded = Math.Floor(minutes / blockMinutes) * blockMinutes;
            return baseDay.AddMinutes(rounded);
        }

        private static bool IsGiornoFestivo(DateTime data)
        {
            var p = App.ParametriGlobali;

            // 1) Sab/Dom (o giorni configurati)
            if (p?.GiorniSempreFestivi != null && p.GiorniSempreFestivi.Any())
            {
                if (p.GiorniSempreFestivi.Contains(data.DayOfWeek))
                    return true;
            }
            else
            {
                // fallback: sab+dom
                if (data.DayOfWeek == DayOfWeek.Saturday || data.DayOfWeek == DayOfWeek.Sunday)
                    return true;
            }

            // 2) Festività ricorrenti
            if (p?.FestivitaRicorrenti != null && p.FestivitaRicorrenti.Any(f => f.Mese == data.Month && f.Giorno == data.Day))
                return true;

            // 3) Festività personalizzate
            if (p?.FestivitaAggiuntive != null && p.FestivitaAggiuntive.Any(d => d.Date == data.Date))
                return true;

            return false;
        }

        private static List<WorkPair> CostruisciCoppieGlobali(List<TimeCardEntry> entries)
        {
            // Ordina e accoppia in modo semplice: (ingresso, uscita)
            // Se ci sono due ingressi consecutivi senza uscita, la coppia mancante viene ignorata.
            var result = new List<WorkPair>();

            foreach (var e in entries.OrderBy(x => x.Ingresso))
            {
                if (e.Uscita <= e.Ingresso) continue;
                result.Add(new WorkPair(e.Ingresso, e.Uscita));
            }

            return result;
        }

        private void AggiornaTotali()
        {
            if (ReportGrid.ItemsSource is not List<ReportRow> rows)
                return;

            int totOrdMin = rows.Sum(r => r.MinutiOrdinarie);
            int totExtraMin = rows.Sum(r => r.MinutiStraordinarie);

            TotaleOrdinarieLabel.Content = $"Totale ordinarie: {ReportRow.FormatMinutes(totOrdMin)}";
            TotaleStraordinarieLabel.Content = $"Totale straordinarie: {ReportRow.FormatMinutes(totExtraMin)}";
        }

        private void SalvaModifiche_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedUser == null)
            {
                MessageBox.Show("Seleziona un utente e carica un report.");
                return;
            }

            if (ReportGrid.ItemsSource is not List<ReportRow> rows)
            {
                MessageBox.Show("Nessun dato da salvare.");
                return;
            }

            string filePath = Path.Combine(_csvFolder, $"{_selectedUser.Id}.csv");
            var newLines = new List<string> { "Data;Ingresso;Uscita" };

            // Ricostruisci tutte le timbrature del mese (giorno+1/2 coppie), mantenendo l'ordine.
            foreach (var r in rows.OrderBy(x => x.Giorno))
            {
                var dayDate = new DateTime(_selectedYear, _selectedMonth, r.Giorno);

                if (TryParsePair(dayDate, r.Entrata1, r.Uscita1, out var s1, out var e1))
                {
                    newLines.Add($"{s1:yyyy-MM-dd};{s1:HH:mm};{e1:HH:mm}");
                }

                if (TryParsePair(dayDate, r.Entrata2, r.Uscita2, out var s2, out var e2))
                {
                    newLines.Add($"{s2:yyyy-MM-dd};{s2:HH:mm};{e2:HH:mm}");
                }
            }

            try
            {
                File.WriteAllLines(filePath, newLines);
                MessageBox.Show("Modifiche salvate.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore nel salvataggio: " + ex.Message);
            }
        }

        private void EsportaTXT_Click(object sender, RoutedEventArgs e)
        {
            if (ReportGrid.ItemsSource is not List<ReportRow> rows)
            {
                MessageBox.Show("Nessun dato da esportare.");
                return;
            }

            var sb = new StringBuilder();
            sb.AppendLine("Giorno\tEntrata1\tUscita1\tDurata1\tEntrata2\tUscita2\tDurata2\tFestivo\tOrdinarie\tStraordinarie");

            foreach (var r in rows)
            {
                sb.AppendLine($"{r.Giorno}\t{r.Entrata1}\t{r.Uscita1}\t{r.Durata1Visual}\t{r.Entrata2}\t{r.Uscita2}\t{r.Durata2Visual}\t{r.IsFestivo}\t{r.OreOrdinarieVisual}\t{r.OreStraordinarieVisual}");
            }

            string outFile = Path.Combine(_csvFolder, $"report_{_selectedUser?.Nome}_{_selectedYear}_{_selectedMonth}.txt");
            try
            {
                File.WriteAllText(outFile, sb.ToString());
                MessageBox.Show("Esportazione completata: " + outFile);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore nell'esportazione: " + ex.Message);
            }
        }

        private void AggiungiTimbratura_Click(object sender, RoutedEventArgs e)
        {
            if (ReportGrid.SelectedItem is not ReportRow row)
            {
                MessageBox.Show("Seleziona una riga.");
                return;
            }

            // Semplice UI testuale: chiede ingresso/uscita e li inserisce nello slot libero.
            string ingresso = Microsoft.VisualBasic.Interaction.InputBox("Inserisci orario ingresso (HH:mm)", "Nuova timbratura", "08:00");
            string uscita = Microsoft.VisualBasic.Interaction.InputBox("Inserisci orario uscita (HH:mm)", "Nuova timbratura", "12:00");

            if (!TimeSpan.TryParse(ingresso, out _) || !TimeSpan.TryParse(uscita, out _))
            {
                MessageBox.Show("Formato orario non valido.");
                return;
            }

            bool inserted = false;
            if (string.IsNullOrWhiteSpace(row.Entrata1) && string.IsNullOrWhiteSpace(row.Uscita1))
            {
                row.Entrata1 = ingresso;
                row.Uscita1 = uscita;
                inserted = true;
            }
            else if (string.IsNullOrWhiteSpace(row.Entrata2) && string.IsNullOrWhiteSpace(row.Uscita2))
            {
                row.Entrata2 = ingresso;
                row.Uscita2 = uscita;
                inserted = true;
            }

            if (!inserted)
            {
                // crea una nuova riga per lo stesso giorno
                if (ReportGrid.ItemsSource is List<ReportRow> rows)
                {
                    var newRow = new ReportRow
                    {
                        Giorno = row.Giorno,
                        Entrata1 = ingresso,
                        Uscita1 = uscita
                    };

                    int index = rows.IndexOf(row);
                    rows.Insert(index + 1, newRow);
                    ReportGrid.Items.Refresh();
                }
            }

            // ricalcola per-giorno
            RecalculateDayInGrid(row.Giorno);
        }
    }
}
