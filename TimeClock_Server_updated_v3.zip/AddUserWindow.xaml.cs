using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class AddUserWindow : Window
    {
        private readonly string _dataFolder;

        public UserProfile? User { get; private set; }
        public UserExtrasRepository.UserExtraData? UserExtra { get; private set; }

        public AddUserWindow(string dataFolder)
        {
            InitializeComponent();

            _dataFolder = dataFolder;

            // Default UI values
            AssunzionePicker.SelectedDate = DateTime.Today;

            GiorniLavorativiCombo.SelectedIndex = 4; // 5
            OreGiornaliereBox.Text = "8";

            // Sequenza automatica basata su utenti.json
            SeqNumberBox.Text = GetNextSequenceNumber().ToString(CultureInfo.InvariantCulture);

            // Aggiorna ore settimanali calcolate
            UpdateOreSettimanaliFromInputs();
        }

        private int GetNextSequenceNumber()
        {
            try
            {
                var path = Path.Combine(_dataFolder, "utenti.json");
                if (!File.Exists(path))
                    return 1;

                var users = JsonSerializer.Deserialize<UserProfile[]>(File.ReadAllText(path));
                if (users == null || users.Length == 0)
                    return 1;

                return users.Max(u => u.SequenceNumber) + 1;
            }
            catch
            {
                return 1;
            }
        }

        private static bool TryParseDoubleFlexible(string? text, out double value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(text))
                return false;

            // Accetta sia virgola sia punto.
            var normalized = text.Trim().Replace(',', '.');
            return double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }

        private int GetSelectedGiorniLavorativi()
        {
            if (GiorniLavorativiCombo.SelectedItem is ComboBoxItem cbi &&
                int.TryParse(cbi.Content?.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int giorni))
            {
                return Math.Max(1, Math.Min(7, giorni));
            }
            return 5;
        }

        private void UpdateOreSettimanaliFromInputs()
        {
            if (!TryParseDoubleFlexible(OreGiornaliereBox.Text, out double oreGiorno) || oreGiorno < 0)
                oreGiorno = 0;

            int giorni = GetSelectedGiorniLavorativi();
            double oreSett = oreGiorno * giorni;

            // Mostra in formato locale (italiano) ma stabile
            OreBox.Text = oreSett.ToString("0.##", CultureInfo.CurrentCulture);
        }

        private void OreGiornaliereBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateOreSettimanaliFromInputs();
        }

        private void GiorniLavorativiCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateOreSettimanaliFromInputs();
        }

        private static string? GetComboValue(ComboBox combo)
        {
            if (combo.SelectedItem is ComboBoxItem cbi)
            {
                var s = cbi.Content?.ToString();
                return string.IsNullOrWhiteSpace(s) ? null : s;
            }
            return null;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(IdBox.Text) ||
                string.IsNullOrWhiteSpace(NomeBox.Text) ||
                string.IsNullOrWhiteSpace(CognomeBox.Text))
            {
                MessageBox.Show("Compila almeno ID, Nome e Cognome.", "Errore", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!TryParseDoubleFlexible(OreGiornaliereBox.Text, out double oreGiorno) || oreGiorno <= 0)
            {
                MessageBox.Show("Inserisci un valore valido per le ore giornaliere previste.", "Errore", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int giorni = GetSelectedGiorniLavorativi();
            double oreSett = oreGiorno * giorni;

            if (AssunzionePicker.SelectedDate == null)
            {
                MessageBox.Show("Seleziona una data di assunzione.", "Errore", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(SeqNumberBox.Text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int seq))
                seq = GetNextSequenceNumber();

            // Salari
            decimal.TryParse(SalarioBaseBox.Text?.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out decimal basePay);
            decimal.TryParse(SalarioExtraBox.Text?.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out decimal extraPay);

            var user = new UserProfile
            {
                SequenceNumber = seq,
                Id = IdBox.Text.Trim(),
                Nome = NomeBox.Text.Trim(),
                Cognome = CognomeBox.Text.Trim(),
                Ruolo = RuoloBox.Text?.Trim() ?? "",
                DataAssunzione = AssunzionePicker.SelectedDate.Value,
                OreContrattoSettimanali = oreSett,
                CompensoOrarioBase = basePay,
                CompensoOrarioExtra = extraPay,
                // Orari previsti: rimangono in anagrafica, ma NON sono più la fonte per stabilire lo straordinario.
                OrarioIngresso1 = GetComboValue(Ingresso1Combo),
                OrarioUscita1 = GetComboValue(Uscita1Combo),
                OrarioIngresso2 = GetComboValue(Ingresso2Combo),
                OrarioUscita2 = GetComboValue(Uscita2Combo)
            };

            User = user;
            UserExtra = new UserExtrasRepository.UserExtraData
            {
                UserId = user.Id,
                OreGiornalierePreviste = oreGiorno,
                GiorniLavorativiSettimana = giorni
            };

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
