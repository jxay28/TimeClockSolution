using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class ReportWindow : Window
    {
        private readonly string _csvFolder;
        private readonly List<UserProfile> _users;

        private UserProfile? _selectedUser;
        private int _selectedYear;
        private int _selectedMonth;

        private readonly ObservableCollection<ReportRow> _righeReport = new();
        private UserExtrasRepository? _extrasRepository;

        // Override manuali (solo le differenze rispetto al calcolo globale)
        private Dictionary<DateTime, bool> _festivoOverrides = new();

        private bool _suppressGridEvents;

        public ReportWindow(string csvFolder, List<UserProfile> users)
        {
            InitializeComponent();
            _csvFolder = csvFolder;
            _users = users ?? new List<UserProfile>();

            UserCombo.ItemsSource = _users;
            UserCombo.DisplayMemberPath = "FullName";

            MonthCombo.ItemsSource = Enumerable.Range(1, 12).ToList();
            MonthCombo.SelectedIndex = DateTime.Today.Month - 1;
            YearBox.Text = DateTime.Today.Year.ToString(CultureInfo.InvariantCulture);

            ReportGrid.ItemsSource = _righeReport;
        }

        // ------------------------------------------------------------
        // Caricamento report
        // ------------------------------------------------------------
        private void CaricaReport_Click(object sender, RoutedEventArgs e)
        {
            if (UserCombo.SelectedItem is not UserProfile user)
            {
                MessageBox.Show("Seleziona un utente.");
                return;
            }

            if (MonthCombo.SelectedItem is not int month || month < 1 || month > 12)
            {
                MessageBox.Show("Seleziona un mese valido.");
                return;
            }

            if (!int.TryParse(YearBox.Text?.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int year) || year < 2000 || year > 2100)
            {
                MessageBox.Show("Inserisci un anno valido (es: 2025).", "Anno non valido", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _selectedUser = user;
            _selectedMonth = month;
            _selectedYear = year;

            _extrasRepository = new UserExtrasRepository(_csvFolder);
            _festivoOverrides = LoadFestivoOverrides(user.Id);

            var coppie = CaricaCoppieDaCsv(user.Id, year, month);
            var coppiePerGiorno = coppie.GroupBy(c => c.Ingresso.Day).ToDictionary(g => g.Key, g => g.OrderBy(x => x.Ingresso).ToList());

            _suppressGridEvents = true;
            try
            {
                _righeReport.Clear();

                int giorniNelMese = DateTime.DaysInMonth(year, month);
                for (int giorno = 1; giorno <= giorniNelMese; giorno++)
                {
                    DateTime data = new(year, month, giorno);
                    bool festivoDefault = GetFestivoEffettivo(data);

                    coppiePerGiorno.TryGetValue(giorno, out var coppieGiorno);
                    coppieGiorno ??= new List<(DateTime Ingresso, DateTime Uscita)>();

                    if (coppieGiorno.Count == 0)
                    {
                        _righeReport.Add(new ReportRow { Giorno = giorno, IsFestivo = festivoDefault });
                        continue;
                    }

                    for (int i = 0; i < coppieGiorno.Count; i += 2)
                    {
                        var riga = new ReportRow { Giorno = giorno, IsFestivo = festivoDefault };

                        var c1 = coppieGiorno[i];
                        riga.Entrata1 = c1.Ingresso.ToString("HH:mm");
                        riga.Uscita1 = c1.Uscita.ToString("HH:mm");

                        if (i + 1 < coppieGiorno.Count)
                        {
                            var c2 = coppieGiorno[i + 1];
                            riga.Entrata2 = c2.Ingresso.ToString("HH:mm");
                            riga.Uscita2 = c2.Uscita.ToString("HH:mm");
                        }

                        _righeReport.Add(riga);
                    }
                }
            }
            finally
            {
                _suppressGridEvents = false;
            }

            // Calcolo blocco per blocco + ordinario/straordinario per giorno
            for (int giorno = 1; giorno <= DateTime.DaysInMonth(year, month); giorno++)
                RecalculateDay(giorno);

            AggiornaTotali();
            ReportGrid.Items.Refresh();
        }

        private List<(DateTime Ingresso, DateTime Uscita)> CaricaCoppieDaCsv(string userId, int year, int month)
        {
            var lista = new List<TimeCardEntry>();
            string path = Path.Combine(_csvFolder, $"{userId}.csv");
            if (!File.Exists(path)) return new List<(DateTime, DateTime)>();

            // Leggo mese + buffer (per eventuali uscite notturne a cavallo)
            var inizio = new DateTime(year, month, 1);
            var fine = inizio.AddMonths(1).AddDays(2);

            foreach (var line in File.ReadAllLines(path).Skip(1))
            {
                var parts = line.Split(';');
                if (parts.Length < 4) continue;

                if (!DateTime.TryParseExact(parts[0].Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime data))
                    continue;
                if (data < inizio || data > fine) continue;

                if (!TimeSpan.TryParse(parts[1].Trim(), CultureInfo.InvariantCulture, out TimeSpan ora))
                    continue;
                string tipo = parts[2].Trim();

                lista.Add(new TimeCardEntry { Data = data.Date + ora, Tipo = tipo });
            }

            // Coppie ingresso/uscita
            var coppie = new List<(DateTime Ingresso, DateTime Uscita)>();
            DateTime? lastIngresso = null;
            foreach (var e in lista.OrderBy(x => x.Data))
            {
                if (e.Tipo.Equals("Entrata", StringComparison.OrdinalIgnoreCase))
                {
                    lastIngresso = e.Data;
                    continue;
                }

                if (e.Tipo.Equals("Uscita", StringComparison.OrdinalIgnoreCase) && lastIngresso != null)
                {
                    var uscita = e.Data;
                    var ingresso = lastIngresso.Value;
                    if (uscita < ingresso)
                        uscita = uscita.AddDays(1);

                    coppie.Add((ingresso, uscita));
                    lastIngresso = null;
                }
            }

            // Filtra: la coppia è attribuita al mese del giorno di ingresso (comportamento storico)
            return coppie.Where(c => c.Ingresso.Year == year && c.Ingresso.Month == month)
                         .OrderBy(c => c.Ingresso)
                         .ToList();
        }

        // ------------------------------------------------------------
        // Ricalcolo giornaliero (allocazione ordinario prima, poi straordinario)
        // ------------------------------------------------------------
        private void RecalculateDay(int giorno, bool? festivoForzato = null)
        {
            if (_selectedUser == null || _selectedMonth < 1 || _selectedYear < 1)
                return;

            var righeGiorno = _righeReport.Where(r => r.Giorno == giorno).ToList();
            if (righeGiorno.Count == 0)
                return;

            DateTime data = new(_selectedYear, _selectedMonth, giorno);

            // Se l'evento arriva da una riga specifica (es. click su Festivo), imposto quel valore a tutto il giorno.
            bool festivo = festivoForzato ?? righeGiorno.First().IsFestivo;
            foreach (var r in righeGiorno)
                r.IsFestivo = festivo;

            int blocco = SnapBlockMinutes(App.ParametriGlobali?.SogliaMinutiStraordinario ?? 15);
            int targetMinuti = GetTargetMinutiGiornalieri(_selectedUser, blocco);

            // Segmenti (per allocare ordinario/straordinario a livello di giorno, attraversando più righe)
            var segmenti = new List<Segmento>();
            foreach (var r in righeGiorno)
            {
                var s1 = CreaSegmentoDaRiga(data, r, 1, blocco);
                if (s1 != null) segmenti.Add(s1);
                var s2 = CreaSegmentoDaRiga(data, r, 2, blocco);
                if (s2 != null) segmenti.Add(s2);
            }

            segmenti = segmenti.OrderBy(s => s.Inizio).ToList();

            // Azzeramento
            foreach (var r in righeGiorno)
            {
                r.OreOrdinarie = 0;
                r.OreStraordinarie = 0;
            }

            if (segmenti.Count == 0)
            {
                // Nessuna timbratura: durate vuote, totali 0
                foreach (var r in righeGiorno)
                {
                    r.Durata1Visual = string.Empty;
                    r.Durata2Visual = string.Empty;
                }
                return;
            }

            if (festivo)
            {
                foreach (var s in segmenti)
                {
                    s.MinutiOrdinarie = 0;
                    s.MinutiStraordinarie = s.MinutiRiconosciuti;
                }
            }
            else
            {
                int residuoOrd = Math.Max(0, targetMinuti);
                foreach (var s in segmenti)
                {
                    int ord = Math.Min(s.MinutiRiconosciuti, residuoOrd);
                    s.MinutiOrdinarie = ord;
                    s.MinutiStraordinarie = s.MinutiRiconosciuti - ord;
                    residuoOrd -= ord;
                }
            }

            // Assegna alle righe (durate visive + somma ore)
            foreach (var s in segmenti)
            {
                if (s.IndiceCoppia == 1)
                    s.Riga.Durata1Visual = FormatMinutes(s.MinutiRiconosciuti);
                else
                    s.Riga.Durata2Visual = FormatMinutes(s.MinutiRiconosciuti);

                s.Riga.OreOrdinarie += s.MinutiOrdinarie / 60.0;
                s.Riga.OreStraordinarie += s.MinutiStraordinarie / 60.0;
            }

            // Durate vuote per coppie non presenti
            foreach (var r in righeGiorno)
            {
                if (string.IsNullOrWhiteSpace(r.Entrata1) || string.IsNullOrWhiteSpace(r.Uscita1))
                    r.Durata1Visual = string.Empty;
                if (string.IsNullOrWhiteSpace(r.Entrata2) || string.IsNullOrWhiteSpace(r.Uscita2))
                    r.Durata2Visual = string.Empty;
            }
        }

        private int GetTargetMinutiGiornalieri(UserProfile user, int bloccoMinuti)
        {
            double oreGiorno = _extrasRepository?.GetOreGiornaliereOrFallback(user, fallbackOre: 8.0, fallbackGiorni: 5) ?? 8.0;
            int minuti = (int)Math.Round(oreGiorno * 60.0);

            // Se uso un blocco (15/30) evito spaccature strane: target arrotondato al multiplo del blocco
            if (bloccoMinuti > 0)
                minuti = (int)(Math.Round(minuti / (double)bloccoMinuti) * bloccoMinuti);

            return Math.Max(0, minuti);
        }

        private Segmento? CreaSegmentoDaRiga(DateTime dataBase, ReportRow riga, int idx, int bloccoMinuti)
        {
            string entrata = idx == 1 ? riga.Entrata1 : riga.Entrata2;
            string uscita = idx == 1 ? riga.Uscita1 : riga.Uscita2;

            if (!TryParseTime(entrata, out var tIn) || !TryParseTime(uscita, out var tOut))
                return null;

            var inizio = dataBase.Date + tIn;
            var fine = dataBase.Date + tOut;
            if (fine < inizio)
                fine = fine.AddDays(1);

            int minuti = CalcolaMinutiRiconosciuti(inizio, fine, bloccoMinuti);

            return new Segmento
            {
                Riga = riga,
                IndiceCoppia = idx,
                Inizio = inizio,
                Fine = fine,
                MinutiRiconosciuti = minuti
            };
        }

        private static int CalcolaMinutiRiconosciuti(DateTime inizio, DateTime fine, int bloccoMinuti)
        {
            if (fine <= inizio) return 0;

            if (bloccoMinuti <= 0)
            {
                return (int)Math.Max(0, Math.Round((fine - inizio).TotalMinutes));
            }

            var start = RoundUpToBlock(inizio, bloccoMinuti);
            var end = RoundDownToBlock(fine, bloccoMinuti);
            if (end <= start) return 0;

            return (int)Math.Max(0, Math.Round((end - start).TotalMinutes));
        }

        private static DateTime RoundUpToBlock(DateTime dt, int bloccoMinuti)
        {
            if (bloccoMinuti <= 0) return dt;
            double minutiDalGiorno = (dt - dt.Date).TotalMinutes;
            double blocchi = Math.Ceiling(minutiDalGiorno / bloccoMinuti);
            return dt.Date.AddMinutes(blocchi * bloccoMinuti);
        }

        private static DateTime RoundDownToBlock(DateTime dt, int bloccoMinuti)
        {
            if (bloccoMinuti <= 0) return dt;
            double minutiDalGiorno = (dt - dt.Date).TotalMinutes;
            double blocchi = Math.Floor(minutiDalGiorno / bloccoMinuti);
            return dt.Date.AddMinutes(blocchi * bloccoMinuti);
        }

        private static string FormatMinutes(int minutes)
        {
            if (minutes <= 0) return "00:00";
            int h = minutes / 60;
            int m = minutes % 60;
            return $"{h:00}:{m:00}";
        }

        private static bool TryParseTime(string? input, out TimeSpan time)
        {
            time = default;
            if (string.IsNullOrWhiteSpace(input)) return false;

            input = input.Trim();

            // Accetto sia "08:00" che "8:00" ecc.
            if (TimeSpan.TryParse(input, CultureInfo.InvariantCulture, out time))
                return true;
            if (TimeSpan.TryParse(input, CultureInfo.CurrentCulture, out time))
                return true;

            // Ultimo tentativo: normalizza 8.30 -> 8:30
            input = input.Replace('.', ':');
            return TimeSpan.TryParse(input, CultureInfo.InvariantCulture, out time);
        }

        private static int SnapBlockMinutes(int raw)
        {
            // Valori ammessi: 0 / 15 / 30
            if (raw <= 0) return 0;
            if (raw <= 15) return 15;
            return 30;
        }

        // ------------------------------------------------------------
        // Festivi (globale + override)
        // ------------------------------------------------------------
        private bool GetFestivoEffettivo(DateTime data)
        {
            // Override manuale?
            if (_festivoOverrides.TryGetValue(data.Date, out bool v))
                return v;

            return IsGlobalHoliday(data);
        }

        private static bool IsGlobalHoliday(DateTime data)
        {
            var p = App.ParametriGlobali;
            if (p == null)
                return data.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday;

            if (p.GiorniSempreFestivi?.Contains(data.DayOfWeek) == true)
                return true;

            // Festività ricorrenti (mese/giorno) + codici speciali per Pasqua
            if (p.FestivitaRicorrenti != null && p.FestivitaRicorrenti.Count > 0)
            {
                bool includePasqua = p.FestivitaRicorrenti.Any(f => f.Mese == 0 && f.Giorno == 0);
                bool includePasquetta = p.FestivitaRicorrenti.Any(f => f.Mese == 0 && f.Giorno == 1);

                if (p.FestivitaRicorrenti.Any(f => f.Mese == data.Month && f.Giorno == data.Day))
                    return true;

                if (includePasqua || includePasquetta)
                {
                    var pasqua = CalculateEasterSunday(data.Year);
                    if (includePasqua && data.Date == pasqua.Date)
                        return true;
                    if (includePasquetta && data.Date == pasqua.AddDays(1).Date)
                        return true;
                }
            }

            if (p.FestivitaAggiuntive != null && p.FestivitaAggiuntive.Any(d => d.Date == data.Date))
                return true;

            return false;
        }

        private static DateTime CalculateEasterSunday(int year)
        {
            // Algoritmo di Meeus/Jones/Butcher (calendario gregoriano)
            int a = year % 19;
            int b = year / 100;
            int c = year % 100;
            int d = b / 4;
            int e = b % 4;
            int f = (b + 8) / 25;
            int g = (b - f + 1) / 3;
            int h = (19 * a + b - d - g + 15) % 30;
            int i = c / 4;
            int k = c % 4;
            int l = (32 + 2 * e + 2 * i - h - k) % 7;
            int m = (a + 11 * h + 22 * l) / 451;
            int month = (h + l - 7 * m + 114) / 31;   // 3 = Marzo, 4 = Aprile
            int day = ((h + l - 7 * m + 114) % 31) + 1;
            return new DateTime(year, month, day);
        }

        private string GetFestivoOverridePath(string userId)
            => Path.Combine(_csvFolder, $"festivo_override_{userId}.json");

        private Dictionary<DateTime, bool> LoadFestivoOverrides(string userId)
        {
            var dict = new Dictionary<DateTime, bool>();
            var path = GetFestivoOverridePath(userId);
            if (!File.Exists(path)) return dict;

            try
            {
                var list = System.Text.Json.JsonSerializer.Deserialize<List<FestivoOverrideEntry>>(File.ReadAllText(path))
                           ?? new List<FestivoOverrideEntry>();

                foreach (var e in list)
                    dict[e.Date.Date] = e.IsFestivo;
            }
            catch
            {
                // file corrotto: ignoro
            }
            return dict;
        }

        private void SaveFestivoOverrides(string userId)
        {
            var path = GetFestivoOverridePath(userId);

            // Carico eventuali override esistenti per non perdere altri mesi
            var dict = LoadFestivoOverrides(userId);

            // Per il mese corrente: salvo solo le differenze rispetto al globale
            var giorniNelMese = DateTime.DaysInMonth(_selectedYear, _selectedMonth);
            for (int giorno = 1; giorno <= giorniNelMese; giorno++)
            {
                DateTime data = new(_selectedYear, _selectedMonth, giorno);
                bool globale = IsGlobalHoliday(data);
                bool attuale = _righeReport.FirstOrDefault(r => r.Giorno == giorno)?.IsFestivo ?? globale;

                if (attuale == globale)
                {
                    dict.Remove(data.Date);
                }
                else
                {
                    dict[data.Date] = attuale;
                }
            }

            var list = dict.OrderBy(k => k.Key)
                           .Select(k => new FestivoOverrideEntry { Date = k.Key.Date, IsFestivo = k.Value })
                           .ToList();

            var json = System.Text.Json.JsonSerializer.Serialize(list, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, json);
        }

        private sealed class FestivoOverrideEntry
        {
            public DateTime Date { get; set; }
            public bool IsFestivo { get; set; }
        }

        private sealed class Segmento
        {
            public required ReportRow Riga { get; set; }
            public int IndiceCoppia { get; set; }
            public required DateTime Inizio { get; set; }
            public required DateTime Fine { get; set; }
            public int MinutiRiconosciuti { get; set; }
            public int MinutiOrdinarie { get; set; }
            public int MinutiStraordinarie { get; set; }
        }

        // ------------------------------------------------------------
        // UI events
        // ------------------------------------------------------------
        private void ReportGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (_suppressGridEvents) return;
            if (e.Row.Item is not ReportRow row) return;

            Dispatcher.BeginInvoke(new Action(() =>
            {
                RecalculateDay(row.Giorno, row.IsFestivo);
                AggiornaTotali();
                ReportGrid.Items.Refresh();
            }), DispatcherPriority.Background);
        }

        private void ReportGrid_CurrentCellChanged(object sender, EventArgs e)
        {
            if (_suppressGridEvents) return;
            if (ReportGrid.CurrentItem is not ReportRow row) return;

            // Commit per checkbox column
            ReportGrid.CommitEdit(DataGridEditingUnit.Row, true);

            RecalculateDay(row.Giorno, row.IsFestivo);
            AggiornaTotali();
            ReportGrid.Items.Refresh();
        }

        private void AggiungiTimbratura_Click(object sender, RoutedEventArgs e)
        {
            if (ReportGrid.SelectedItem is not ReportRow row) return;

            if (string.IsNullOrWhiteSpace(row.Entrata1) && string.IsNullOrWhiteSpace(row.Uscita1))
            {
                row.Entrata1 = "08:00";
                row.Uscita1 = "12:00";
            }
            else if (string.IsNullOrWhiteSpace(row.Entrata2) && string.IsNullOrWhiteSpace(row.Uscita2))
            {
                row.Entrata2 = "13:00";
                row.Uscita2 = "17:00";
            }
            else
            {
                // nuova riga (ulteriori coppie)
                var newRow = new ReportRow
                {
                    Giorno = row.Giorno,
                    IsFestivo = row.IsFestivo,
                    Entrata1 = "08:00",
                    Uscita1 = "12:00"
                };

                int idx = _righeReport.IndexOf(row);
                if (idx >= 0 && idx + 1 <= _righeReport.Count)
                    _righeReport.Insert(idx + 1, newRow);
                else
                    _righeReport.Add(newRow);
            }

            RecalculateDay(row.Giorno, row.IsFestivo);
            AggiornaTotali();
            ReportGrid.Items.Refresh();
        }

        private void SalvaModifiche_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedUser == null)
            {
                MessageBox.Show("Carica prima un report.");
                return;
            }

            string file = Path.Combine(_csvFolder, $"{_selectedUser.Id}.csv");
            var tutte = new List<TimeCardEntry>();

            if (File.Exists(file))
            {
                foreach (var line in File.ReadAllLines(file).Skip(1))
                {
                    var parts = line.Split(';');
                    if (parts.Length < 4) continue;
                    if (!DateTime.TryParseExact(parts[0].Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime data))
                        continue;
                    if (!TimeSpan.TryParse(parts[1].Trim(), CultureInfo.InvariantCulture, out TimeSpan ora))
                        continue;
                    string tipo = parts[2].Trim();
                    tutte.Add(new TimeCardEntry { Data = data.Date + ora, Tipo = tipo });
                }
            }

            // Tengo fuori-mese
            var fuoriMese = tutte.Where(t => t.Data.Year != _selectedYear || t.Data.Month != _selectedMonth).ToList();

            // Ricostruisco mese da griglia
            var meseNuovo = new List<TimeCardEntry>();
            foreach (var r in _righeReport)
            {
                var data = new DateTime(_selectedYear, _selectedMonth, r.Giorno);
                AggiungiCoppia(meseNuovo, data, r.Entrata1, r.Uscita1);
                AggiungiCoppia(meseNuovo, data, r.Entrata2, r.Uscita2);
            }

            var finale = fuoriMese.Concat(meseNuovo)
                                  .OrderBy(t => t.Data)
                                  .ToList();

            var sb = new StringBuilder();
            sb.AppendLine("Data;Ora;Tipo;Note");
            foreach (var e in finale)
                sb.AppendLine($"{e.Data:yyyy-MM-dd};{e.Data:HH:mm};{e.Tipo};");

            File.WriteAllText(file, sb.ToString(), Encoding.UTF8);

            // Salvo anche override festivi
            SaveFestivoOverrides(_selectedUser.Id);

            MessageBox.Show("Modifiche salvate.");
        }

        private static void AggiungiCoppia(List<TimeCardEntry> list, DateTime data, string? entrata, string? uscita)
        {
            if (!TryParseTime(entrata, out var tIn) || !TryParseTime(uscita, out var tOut))
                return;

            list.Add(new TimeCardEntry { Data = data.Date + tIn, Tipo = "Entrata" });
            list.Add(new TimeCardEntry { Data = data.Date + tOut, Tipo = "Uscita" });
        }

        private void EsportaTXT_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedUser == null)
            {
                MessageBox.Show("Carica prima un report.");
                return;
            }

            string reportFile = Path.Combine(_csvFolder, $"Report_{_selectedUser.Id}_{_selectedYear}_{_selectedMonth:00}.txt");
            var sb = new StringBuilder();
            sb.AppendLine("Giorno;Entrata1;Uscita1;Durata1;Entrata2;Uscita2;Durata2;Festivo;Ordinarie;Straordinarie");

            foreach (var r in _righeReport)
            {
                sb.AppendLine($"{r.Giorno:00};{r.Entrata1};{r.Uscita1};{r.Durata1Visual};{r.Entrata2};{r.Uscita2};{r.Durata2Visual};{(r.IsFestivo ? "SI" : "NO")};{r.OreOrdinarie:0.##};{r.OreStraordinarie:0.##}");
            }

            File.WriteAllText(reportFile, sb.ToString(), Encoding.UTF8);
            MessageBox.Show($"Report esportato in:\n{reportFile}");
        }

        private void AggiornaTotali()
        {
            double totOrd = _righeReport.Sum(r => r.OreOrdinarie);
            double totStr = _righeReport.Sum(r => r.OreStraordinarie);

            TotOrdinarieText.Text = totOrd.ToString("0.##", CultureInfo.CurrentCulture);
            TotStraordinarieText.Text = totStr.ToString("0.##", CultureInfo.CurrentCulture);
        }
    }

    public class ReportRow
    {
        public int Giorno { get; set; }
        public bool IsFestivo { get; set; }

        public string Entrata1 { get; set; } = string.Empty;
        public string Uscita1 { get; set; } = string.Empty;
        public string Durata1Visual { get; set; } = string.Empty;

        public string Entrata2 { get; set; } = string.Empty;
        public string Uscita2 { get; set; } = string.Empty;
        public string Durata2Visual { get; set; } = string.Empty;

        public double OreOrdinarie { get; set; }
        public double OreStraordinarie { get; set; }
    }
}
