using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class App : Application
    {
        public static ParametriStraordinari ParametriGlobali { get; private set; } = new ParametriStraordinari();

        public static string GetParametriPath(string dataFolder)
            => Path.Combine(dataFolder ?? string.Empty, "parametri_straordinari.json");

        public static void CaricaParametriGlobali(string dataFolder)
        {
            var p = new ParametriStraordinari();

            try
            {
                var path = GetParametriPath(dataFolder);
                if (!string.IsNullOrWhiteSpace(dataFolder) && File.Exists(path))
                {
                    var json = File.ReadAllText(path);
                    p = JsonSerializer.Deserialize<ParametriStraordinari>(json) ?? new ParametriStraordinari();
                }
            }
            catch
            {
                // Se il JSON è corrotto o non leggibile, ripieghiamo su default sicuri.
                p = new ParametriStraordinari();
            }

            ParametriGlobali = EnsureDefaults(p);

            // Se il file non esiste, lo creiamo subito (per avere una fonte di verità persistente).
            try
            {
                if (!string.IsNullOrWhiteSpace(dataFolder))
                {
                    Directory.CreateDirectory(dataFolder);
                    var path = GetParametriPath(dataFolder);
                    if (!File.Exists(path))
                        SalvaParametriGlobali(dataFolder);
                }
            }
            catch
            {
                // non blocchiamo l'app
            }
        }

        public static void SalvaParametriGlobali(string dataFolder)
        {
            if (string.IsNullOrWhiteSpace(dataFolder))
                return;

            Directory.CreateDirectory(dataFolder);
            var path = GetParametriPath(dataFolder);

            ParametriGlobali = EnsureDefaults(ParametriGlobali);

            var json = JsonSerializer.Serialize(ParametriGlobali, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, json);
        }

        private static ParametriStraordinari EnsureDefaults(ParametriStraordinari p)
        {
            p ??= new ParametriStraordinari();

            p.GiorniSempreFestivi ??= new List<DayOfWeek>();
            p.FestivitaRicorrenti ??= new List<FestivitaRicorrente>();
            p.FestivitaAggiuntive ??= new List<DateTime>();

            // Valori ammessi: 0 / 15 / 30
            if (p.SogliaMinutiStraordinario != 0 && p.SogliaMinutiStraordinario != 15 && p.SogliaMinutiStraordinario != 30)
                p.SogliaMinutiStraordinario = 15;

            // Weekend di default
            if (!p.GiorniSempreFestivi.Contains(DayOfWeek.Saturday))
                p.GiorniSempreFestivi.Add(DayOfWeek.Saturday);
            if (!p.GiorniSempreFestivi.Contains(DayOfWeek.Sunday))
                p.GiorniSempreFestivi.Add(DayOfWeek.Sunday);

            // Festività nazionali fisse (default se vuoto)
            if (p.FestivitaRicorrenti.Count == 0)
            {
                var fisse = new (int Mese, int Giorno)[]
                {
                    (1,1), (1,6),
                    (4,25), (5,1), (6,2),
                    (8,15),
                    (11,1),
                    (12,8), (12,25), (12,26)
                };

                foreach (var (m, g) in fisse)
                    p.FestivitaRicorrenti.Add(new FestivitaRicorrente { Mese = m, Giorno = g });
            }

            // Normalizziamo: niente duplicati
            p.FestivitaRicorrenti = p.FestivitaRicorrenti
                .Where(x => x != null)
                .GroupBy(x => (x.Mese, x.Giorno))
                .Select(g => g.First())
                .ToList();

            p.FestivitaAggiuntive = p.FestivitaAggiuntive
                .Select(d => d.Date)
                .Distinct()
                .OrderBy(d => d)
                .ToList();

            return p;
        }
    }
}
