using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    /// <summary>
    /// Genera i file di report per il commercialista e per il gestionale paghe.
    /// </summary>
    public class ReportService
    {
        public void GenerateReports(IEnumerable<UserProfile> users, IEnumerable<PaySummary> summaries, int year, int month, string outputFolder)
        {
            var reportCommLines = new List<string> { "IdUtente,CodiceFiscale,Mese,Anno,OreOrdinarie,OreStraordinarie" };
            var reportPagheLines = new List<string> { "IdUtente,AnnoMese,OreOrdinarie,OreStraordinarie,CompensoBase,CompensoStraordinario" };

            string monthStr = month.ToString("D2");

            foreach (var user in users)
            {
                var summary = summaries.FirstOrDefault(s => s.UserId == user.Id);
                if (summary == null) continue;
                // CodiceFiscale è lasciato vuoto come placeholder
                reportCommLines.Add($"{user.Id},,{monthStr},{year},{summary.OreOrdinarie:F2},{summary.OreStraordinarie:F2}");
                reportPagheLines.Add($"{user.Id},{year}{monthStr},{summary.OreOrdinarie:F2},{summary.OreStraordinarie:F2},{summary.CompensoOrdinarie:F2},{summary.CompensoStraordinarie:F2}");
            }

            File.WriteAllLines(Path.Combine(outputFolder, $"report_commercialista_{year}{monthStr}.csv"), reportCommLines);
            File.WriteAllLines(Path.Combine(outputFolder, $"report_paghe_{year}{monthStr}.csv"), reportPagheLines);
        }

        private bool ÈFestivo(DateTime data)
        {
            var p = App.ParametriGlobali;

            // Sabato/domenica o giorni scelti
            if (p.GiorniSempreFestivi.Contains(data.DayOfWeek))
                return true;

            // Festività ricorrenti
            // Festività ricorrenti (date fisse) + marker per Pasqua (mese=0)
            if (p.FestivitaRicorrenti != null)
            {
                // Marker: (Mese=0,Giorno=0) = Pasqua; (Mese=0,Giorno=1) = Lunedì dell'Angelo
                bool includePasqua = p.FestivitaRicorrenti.Any(f => f.Mese == 0 && f.Giorno == 0);
                bool includePasquetta = p.FestivitaRicorrenti.Any(f => f.Mese == 0 && f.Giorno == 1);
                if (includePasqua || includePasquetta)
                {
                    var pasqua = CalcolaPasqua(data.Year);
                    if (includePasqua && data.Date == pasqua)
                        return true;
                    if (includePasquetta && data.Date == pasqua.AddDays(1))
                        return true;
                }

                // Date fisse
                foreach (var f in p.FestivitaRicorrenti)
                {
                    if (f.Mese >= 1 && f.Giorno >= 1 && data.Month == f.Mese && data.Day == f.Giorno)
                        return true;
                }
            }

            // Festività extra specifiche
            if (p.FestivitaAggiuntive != null && p.FestivitaAggiuntive.Any(d => d.Date == data.Date))
                return true;

            return false;
        }

        private static DateTime CalcolaPasqua(int year)
        {
            // Algoritmo Meeus/Jones/Butcher (gregoriano)
            int a = year % 19;
            int b = year / 100;
            int c = year % 100;
            int d = b / 4;
            int e = b % 4;
            int f = (b + 8) / 25;
            int g = (b - f + 1) / 3;
            int h = (19 * a + b - d - g + 15) % 30;
            int i = c / 4;
            int k = c % 4;
            int l = (32 + 2 * e + 2 * i - h - k) % 7;
            int m = (a + 11 * h + 22 * l) / 451;
            int month = (h + l - 7 * m + 114) / 31;
            int day = ((h + l - 7 * m + 114) % 31) + 1;
            return new DateTime(year, month, day);
        }

    }
}