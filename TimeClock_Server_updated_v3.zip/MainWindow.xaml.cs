using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using TimeClock.Core.Models;

namespace TimeClock.Server
{
    public partial class MainWindow : Window
    {
        private string _csvFolder = string.Empty;

        private readonly List<UserProfile> _users = new();
        private UserExtrasRepository? _extrasRepo;

        private bool _suppressParamUiEvents;
        private bool _snappingSlider;

        public MainWindow()
        {
            InitializeComponent();

            // UI di partenza: nessuna cartella selezionata.
            UsersGrid.ItemsSource = _users;
            HolidayGrid.ItemsSource = new List<Holiday>();
            CustomHolidayList.ItemsSource = new List<DateTime>();
        }

        #region Cartella dati

        private void SelectCsvFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Seleziona la cartella dove sono salvati utenti, timbrature e parametri.",
                ShowNewFolderButton = true
            };

            if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
                return;

            _csvFolder = dialog.SelectedPath;
            CsvPathBox.Text = _csvFolder;

            Directory.CreateDirectory(_csvFolder);

            _extrasRepo = new UserExtrasRepository(_csvFolder);

            CaricaUtenti();
            CaricaParametriGlobaliEUi();
        }

        #endregion

        #region Utenti

        private void CaricaUtenti()
        {
            _users.Clear();

            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                UsersGrid.ItemsSource = null;
                UsersGrid.ItemsSource = _users;
                return;
            }

            var usersFile = Path.Combine(_csvFolder, "utenti.json");
            if (!File.Exists(usersFile))
            {
                UsersGrid.ItemsSource = null;
                UsersGrid.ItemsSource = _users;
                return;
            }

            try
            {
                var loaded = JsonSerializer.Deserialize<List<UserProfile>>(File.ReadAllText(usersFile)) ?? new List<UserProfile>();
                _users.AddRange(loaded.OrderBy(u => u.SequenceNumber));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Errore nel caricamento di utenti.json: {ex.Message}", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            UsersGrid.ItemsSource = null;
            UsersGrid.ItemsSource = _users;
        }

        private void SalvaUtenti()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            var usersFile = Path.Combine(_csvFolder, "utenti.json");
            var json = JsonSerializer.Serialize(_users.OrderBy(u => u.SequenceNumber).ToList(), new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(usersFile, json);
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dlg = new AddUserWindow(_csvFolder)
            {
                Owner = this
            };

            var ok = dlg.ShowDialog();
            if (ok != true || dlg.User == null)
                return;

            // evita ID duplicati
            if (_users.Any(u => string.Equals(u.Id, dlg.User.Id, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show("Esiste già un utente con lo stesso ID.", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            _users.Add(dlg.User);
            SalvaUtenti();

            if (_extrasRepo != null && dlg.UserExtra != null)
            {
                _extrasRepo.Set(dlg.UserExtra.UserId, dlg.UserExtra.OreGiornalierePreviste, dlg.UserExtra.GiorniLavorativiSettimana);
                _extrasRepo.Save();
            }

            UsersGrid.ItemsSource = null;
            UsersGrid.ItemsSource = _users.OrderBy(u => u.SequenceNumber).ToList();
        }

        #endregion

        #region Report

        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_users.Count == 0)
            {
                MessageBox.Show("Nessun utente disponibile. Aggiungi almeno un utente.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var win = new ReportWindow(_csvFolder, _users)
            {
                Owner = this
            };
            win.Show();
        }

        #endregion

        #region Parametri globali (JSON)

        private static int SnapBlockMinutes(double value)
        {
            // Slider consentito: 0, 15, 30
            var allowed = new[] { 0, 15, 30 };
            var v = (int)Math.Round(value);
            return allowed.OrderBy(a => Math.Abs(a - v)).First();
        }

        private void CaricaParametriGlobaliEUi()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            // 1) carica parametri JSON (o crea default)
            App.CaricaParametriGlobali(_csvFolder);

            // 2) migrazione "soft": se esiste festivita.csv, importiamo le date in FestivitaAggiuntive
            ImportaFestivitaLegacyDaCsv();

            // 3) refresh UI
            CaricaUiDaParametri();
        }

        private void CaricaUiDaParametri()
        {
            if (App.ParametriGlobali == null)
                return;

            _suppressParamUiEvents = true;
            try
            {
                var block = SnapBlockMinutes(App.ParametriGlobali.SogliaMinutiStraordinario);
                OvertimeSlider.Value = block;
                SogliaLabel.Text = block == 0 ? "Nessun arrotondamento" : $"Blocco: {block} min";

                SaturdayCheck.IsChecked = App.ParametriGlobali.GiorniSempreFestivi.Contains(DayOfWeek.Saturday);
                SundayCheck.IsChecked = App.ParametriGlobali.GiorniSempreFestivi.Contains(DayOfWeek.Sunday);

                // Festività ricorrenti (mese/giorno) + 2 codici speciali: (0,0)=Pasqua, (0,1)=Lunedì dell'Angelo
                ImpostaCheckRicorrente(Holiday_0101, 1, 1);
                ImpostaCheckRicorrente(Holiday_0106, 1, 6);
                ImpostaCheckRicorrente(Holiday_EASTER, 0, 0);
                ImpostaCheckRicorrente(Holiday_EASTERMON, 0, 1);
                ImpostaCheckRicorrente(Holiday_0425, 4, 25);
                ImpostaCheckRicorrente(Holiday_0501, 5, 1);
                ImpostaCheckRicorrente(Holiday_0602, 6, 2);
                ImpostaCheckRicorrente(Holiday_0815, 8, 15);
                ImpostaCheckRicorrente(Holiday_1101, 11, 1);
                ImpostaCheckRicorrente(Holiday_1208, 12, 8);
                ImpostaCheckRicorrente(Holiday_1225, 12, 25);
                ImpostaCheckRicorrente(Holiday_1226, 12, 26);

                // Lista festività personalizzate
                var aggiuntive = (App.ParametriGlobali.FestivitaAggiuntive ?? new List<DateTime>())
                    .Select(d => d.Date)
                    .Distinct()
                    .OrderBy(d => d)
                    .ToList();
                CustomHolidayList.ItemsSource = aggiuntive;

                // Tab "Festività" (grid)
                HolidayGrid.ItemsSource = aggiuntive
                    .Select(d => new Holiday { Data = d, Descrizione = "Personalizzata" })
                    .OrderBy(h => h.Data)
                    .ToList();
            }
            finally
            {
                _suppressParamUiEvents = false;
            }
        }

        private void SalvaParametri()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
                return;

            App.SalvaParametriGlobali(_csvFolder);
        }

        private bool ContieneRicorrente(int mese, int giorno)
        {
            return App.ParametriGlobali?.FestivitaRicorrenti?.Any(f => f.Mese == mese && f.Giorno == giorno) == true;
        }

        private void ImpostaCheckRicorrente(CheckBox cb, int mese, int giorno)
        {
            if (cb == null) return;
            cb.IsChecked = ContieneRicorrente(mese, giorno);
        }

        private void SetRicorrente(int mese, int giorno, bool enabled)
        {
            if (App.ParametriGlobali == null)
                return;

            App.ParametriGlobali.FestivitaRicorrenti ??= new List<FestivitaRicorrente>();

            var esiste = App.ParametriGlobali.FestivitaRicorrenti.Any(f => f.Mese == mese && f.Giorno == giorno);
            if (enabled && !esiste)
                App.ParametriGlobali.FestivitaRicorrenti.Add(new FestivitaRicorrente { Mese = mese, Giorno = giorno });
            else if (!enabled && esiste)
                App.ParametriGlobali.FestivitaRicorrenti = App.ParametriGlobali.FestivitaRicorrenti
                    .Where(f => !(f.Mese == mese && f.Giorno == giorno))
                    .ToList();
        }

        private void OvertimeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_suppressParamUiEvents)
                return;

            if (App.ParametriGlobali == null)
                return;

            if (_snappingSlider)
                return;

            try
            {
                _snappingSlider = true;

                var snapped = SnapBlockMinutes(e.NewValue);
                if (Math.Abs(OvertimeSlider.Value - snapped) > 0.01)
                    OvertimeSlider.Value = snapped;

                App.ParametriGlobali.SogliaMinutiStraordinario = snapped;
                SogliaLabel.Text = snapped == 0 ? "Nessun arrotondamento" : $"Blocco: {snapped} min";
                SalvaParametri();
            }
            finally
            {
                _snappingSlider = false;
            }
        }

        private void WeekendCheck_Changed(object sender, RoutedEventArgs e)
        {
            if (_suppressParamUiEvents)
                return;

            if (App.ParametriGlobali == null)
                return;

            App.ParametriGlobali.GiorniSempreFestivi ??= new List<DayOfWeek>();

            AggiornaGiornoSempreFestivo(DayOfWeek.Saturday, SaturdayCheck.IsChecked == true);
            AggiornaGiornoSempreFestivo(DayOfWeek.Sunday, SundayCheck.IsChecked == true);

            SalvaParametri();
        }

        private void AggiornaGiornoSempreFestivo(DayOfWeek day, bool enabled)
        {
            if (App.ParametriGlobali == null)
                return;

            var list = App.ParametriGlobali.GiorniSempreFestivi ??= new List<DayOfWeek>();
            var exists = list.Contains(day);
            if (enabled && !exists) list.Add(day);
            if (!enabled && exists) list.Remove(day);
        }

        private void HolidayCheck_Changed(object sender, RoutedEventArgs e)
        {
            if (_suppressParamUiEvents)
                return;

            if (sender is not CheckBox cb)
                return;

            // Mappiamo i checkbox -> (mese,giorno)
            (int mese, int giorno)? key = cb.Name switch
            {
                nameof(Holiday_0101) => (1, 1),
                nameof(Holiday_0106) => (1, 6),
                nameof(Holiday_EASTER) => (0, 0),
                nameof(Holiday_EASTERMON) => (0, 1),
                nameof(Holiday_0425) => (4, 25),
                nameof(Holiday_0501) => (5, 1),
                nameof(Holiday_0602) => (6, 2),
                nameof(Holiday_0815) => (8, 15),
                nameof(Holiday_1101) => (11, 1),
                nameof(Holiday_1208) => (12, 8),
                nameof(Holiday_1225) => (12, 25),
                nameof(Holiday_1226) => (12, 26),
                _ => null
            };

            if (key == null || App.ParametriGlobali == null)
                return;

            SetRicorrente(key.Value.mese, key.Value.giorno, cb.IsChecked == true);
            SalvaParametri();
        }

        private void AddCustomHolidayButton_Click(object sender, RoutedEventArgs e)
        {
            if (App.ParametriGlobali == null)
                return;

            if (CustomHolidayPicker.SelectedDate == null)
            {
                MessageBox.Show("Seleziona una data.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var d = CustomHolidayPicker.SelectedDate.Value.Date;
            App.ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();

            if (!App.ParametriGlobali.FestivitaAggiuntive.Any(x => x.Date == d))
                App.ParametriGlobali.FestivitaAggiuntive.Add(d);

            SalvaParametri();
            CaricaUiDaParametri();
        }

        private void SaveOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            SalvaParametri();
            MessageBox.Show("Parametri salvati in parametri_straordinari.json", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CancelOvertimeParamsButton_Click(object sender, RoutedEventArgs e)
        {
            CaricaParametriGlobaliEUi();
            MessageBox.Show("Parametri ricaricati dal file.", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        #endregion

        #region Festività (tab)

        private void AddHoliday_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_csvFolder))
            {
                MessageBox.Show("Seleziona prima la cartella CSV.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (HolidayDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Seleziona una data.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var date = HolidayDatePicker.SelectedDate.Value.Date;
            var descr = HolidayDescriptionBox.Text?.Trim() ?? string.Empty;

            App.ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();
            if (!App.ParametriGlobali.FestivitaAggiuntive.Any(d => d.Date == date))
                App.ParametriGlobali.FestivitaAggiuntive.Add(date);

            // Legacy/export: scriviamo anche festivita.csv con descrizione (opzionale)
            try
            {
                var legacy = Path.Combine(_csvFolder, "festivita.csv");
                File.AppendAllLines(legacy, new[] { $"{date:yyyy-MM-dd};{descr}" });
            }
            catch
            {
                // non bloccare
            }

            SalvaParametri();
            CaricaUiDaParametri();
        }

        private void ImportaFestivitaLegacyDaCsv()
        {
            if (string.IsNullOrWhiteSpace(_csvFolder) || App.ParametriGlobali == null)
                return;

            var legacy = Path.Combine(_csvFolder, "festivita.csv");
            if (!File.Exists(legacy))
                return;

            try
            {
                App.ParametriGlobali.FestivitaAggiuntive ??= new List<DateTime>();

                foreach (var line in File.ReadAllLines(legacy))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split(';');
                    if (parts.Length == 0) continue;
                    if (!DateTime.TryParse(parts[0], CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
                        continue;

                    d = d.Date;
                    if (!App.ParametriGlobali.FestivitaAggiuntive.Any(x => x.Date == d))
                        App.ParametriGlobali.FestivitaAggiuntive.Add(d);
                }

                // salviamo solo se abbiamo effettivamente una lista (non facciamo dedup perfetto qui)
                SalvaParametri();
            }
            catch
            {
                // ignoriamo eventuali CSV malformati
            }
        }

        #endregion
    }
}
